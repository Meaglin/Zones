import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import net.minecraft.server.MinecraftServer;

public class Main
{
  public static void main(String[] paramArrayOfString)
    throws IOException
  {
    if (!new File("minecraft_server.jar").exists())
    {
      System.out.println("minecraft_server.jar not found, downloading...");
      URL localURL = new URL("http://minecraft.net/download/minecraft_server.jar");
      ReadableByteChannel localReadableByteChannel = Channels.newChannel(localURL.openStream());
      FileOutputStream localFileOutputStream = new FileOutputStream("minecraft_server.jar");
      localFileOutputStream.getChannel().transferFrom(localReadableByteChannel, 0L, 16777216L);
      System.out.println("Finished downloading, starting server");
    }
    if (checkForUpdate())
      System.out.println("Update found.");
    MinecraftServer.main(paramArrayOfString);
  }

  public static boolean checkForUpdate()
  {
    return false;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Main
 * JD-Core Version:    0.6.0
 */