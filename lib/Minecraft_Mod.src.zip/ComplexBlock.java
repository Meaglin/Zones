public abstract interface ComplexBlock
{
  public abstract int getX();

  public abstract int getY();

  public abstract int getZ();

  public abstract void update();
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     ComplexBlock
 * JD-Core Version:    0.6.0
 */