import java.io.File;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class fk
{
  public static Logger a = Logger.getLogger("Minecraft");

  public static void a()
  {
    gx localgx = new gx();
    a.setUseParentHandlers(false);
    ConsoleHandler localConsoleHandler = new ConsoleHandler();
    localConsoleHandler.setFormatter(localgx);
    a.addHandler(localConsoleHandler);
    try
    {
      FileHandler localFileHandler1 = new FileHandler("server.log");
      localFileHandler1.setFormatter(localgx);
      a.addHandler(localFileHandler1);
    }
    catch (Exception localException1)
    {
      a.log(Level.WARNING, "Failed to log to server log", localException1);
    }
    File localFile = new File("logs");
    try
    {
      if (!localFile.exists())
        localFile.mkdir();
      FileHandler localFileHandler2 = new FileHandler("logs/server_" + (int)(System.currentTimeMillis() / 1000L) + ".log");
      localFileHandler2.setFormatter(localgx);
      a.addHandler(localFileHandler2);
    }
    catch (Exception localException2)
    {
      a.log(Level.WARNING, "Failed to log to server log", localException2);
    }
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     fk
 * JD-Core Version:    0.6.0
 */