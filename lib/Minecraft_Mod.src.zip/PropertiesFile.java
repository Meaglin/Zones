import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class PropertiesFile
{
  private static final Logger log = Logger.getLogger("Minecraft");
  private Properties properties;
  private String fileName;

  public PropertiesFile(String paramString)
  {
    this.fileName = paramString;
    this.properties = new Properties();
    File localFile = new File(paramString);
    if (localFile.exists())
      load();
    else
      save();
  }

  public void load()
  {
    try
    {
      this.properties.load(new FileInputStream(this.fileName));
    }
    catch (IOException localIOException)
    {
      log.log(Level.SEVERE, "Unable to load " + this.fileName, localIOException);
    }
  }

  public void save()
  {
    try
    {
      this.properties.store(new FileOutputStream(this.fileName), "Minecraft Properties File");
    }
    catch (IOException localIOException)
    {
      log.log(Level.SEVERE, "Unable to save " + this.fileName, localIOException);
    }
  }

  public String getString(String paramString1, String paramString2)
  {
    if (this.properties.containsKey(paramString1))
      return this.properties.getProperty(paramString1);
    setString(paramString1, paramString2);
    return paramString2;
  }

  public void setString(String paramString1, String paramString2)
  {
    this.properties.setProperty(paramString1, paramString2);
    save();
  }

  public int getInt(String paramString, int paramInt)
  {
    if (this.properties.containsKey(paramString))
      return Integer.parseInt(this.properties.getProperty(paramString));
    setInt(paramString, paramInt);
    return paramInt;
  }

  public void setInt(String paramString, int paramInt)
  {
    this.properties.setProperty(paramString, String.valueOf(paramInt));
    save();
  }

  public long getLong(String paramString, long paramLong)
  {
    if (this.properties.containsKey(paramString))
      return Long.parseLong(this.properties.getProperty(paramString));
    setLong(paramString, paramLong);
    return paramLong;
  }

  public void setLong(String paramString, long paramLong)
  {
    this.properties.setProperty(paramString, String.valueOf(paramLong));
    save();
  }

  public boolean getBoolean(String paramString, boolean paramBoolean)
  {
    if (this.properties.containsKey(paramString))
      return Boolean.parseBoolean(this.properties.getProperty(paramString));
    setBoolean(paramString, paramBoolean);
    return paramBoolean;
  }

  public void setBoolean(String paramString, boolean paramBoolean)
  {
    this.properties.setProperty(paramString, String.valueOf(paramBoolean));
    save();
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     PropertiesFile
 * JD-Core Version:    0.6.0
 */