public class Block
{
  private int type;
  private int x;
  private int y;
  private int z;
  private Block.Face faceClicked;
  private int status;
  private int data;

  public Block()
  {
  }

  public Block(int paramInt)
  {
    this.type = paramInt;
  }

  public Block(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.type = paramInt1;
    this.x = paramInt2;
    this.y = paramInt3;
    this.z = paramInt4;
  }

  public Block(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this.type = paramInt1;
    this.x = paramInt2;
    this.y = paramInt3;
    this.z = paramInt4;
    this.data = paramInt5;
  }

  public int getType()
  {
    return this.type;
  }

  public void setType(int paramInt)
  {
    this.type = paramInt;
  }

  public int getX()
  {
    return this.x;
  }

  public void setX(int paramInt)
  {
    this.x = paramInt;
  }

  public int getY()
  {
    return this.y;
  }

  public void setY(int paramInt)
  {
    this.y = paramInt;
  }

  public int getZ()
  {
    return this.z;
  }

  public void setZ(int paramInt)
  {
    this.z = paramInt;
  }

  public Block.Face getFaceClicked()
  {
    return this.faceClicked;
  }

  public void setFaceClicked(Block.Face paramFace)
  {
    this.faceClicked = paramFace;
  }

  public int getStatus()
  {
    return this.status;
  }

  public void setStatus(int paramInt)
  {
    this.status = paramInt;
  }

  public int getData()
  {
    return this.data;
  }

  public void setData(int paramInt)
  {
    this.data = paramInt;
  }

  public void update()
  {
    etc.getServer().setBlock(this);
  }

  public static enum Face
  {
    Top(1), Bottom(0), Left(3), Right(2), Front(5), Back(4);

    private final int id;

    private Face(int paramInt)
    {
      this.id = paramInt;
    }

    public static Face fromId(int paramInt)
    {
      for (Face localFace : values())
        if (localFace.id == paramInt)
          return localFace;
      return null;
    }
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Block
 * JD-Core Version:    0.6.0
 */