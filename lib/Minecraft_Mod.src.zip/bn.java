import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import net.minecraft.server.MinecraftServer;

public class bn extends Thread
{
  private MinecraftServer server;

  public bn(MinecraftServer paramMinecraftServer)
  {
    this.server = paramMinecraftServer;
  }

  public void run()
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(System.in));
    String str = null;
    try
    {
      while ((!this.server.g) && ((str = localBufferedReader.readLine()) != null))
      {
        if (etc.getInstance().parseConsoleCommand(str, this.server))
          continue;
        this.server.a(str, this.server);
      }
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     bn
 * JD-Core Version:    0.6.0
 */