public abstract class PluginListener
{
  public void onPlayerMove(Player paramPlayer, Location paramLocation1, Location paramLocation2)
  {
  }

  public boolean onTeleport(Player paramPlayer, Location paramLocation1, Location paramLocation2)
  {
    return false;
  }

  public String onLoginChecks(String paramString)
  {
    return null;
  }

  public void onLogin(Player paramPlayer)
  {
  }

  public void onDisconnect(Player paramPlayer)
  {
  }

  public boolean onChat(Player paramPlayer, String paramString)
  {
    return false;
  }

  public boolean onCommand(Player paramPlayer, String[] paramArrayOfString)
  {
    return false;
  }

  public boolean onConsoleCommand(String[] paramArrayOfString)
  {
    return false;
  }

  public void onBan(Player paramPlayer1, Player paramPlayer2, String paramString)
  {
  }

  public void onIpBan(Player paramPlayer1, Player paramPlayer2, String paramString)
  {
  }

  public void onKick(Player paramPlayer1, Player paramPlayer2, String paramString)
  {
  }

  public boolean onBlockCreate(Player paramPlayer, Block paramBlock1, Block paramBlock2, int paramInt)
  {
    return false;
  }

  public boolean onBlockDestroy(Player paramPlayer, Block paramBlock)
  {
    return false;
  }

  public void onArmSwing(Player paramPlayer)
  {
  }

  public boolean onInventoryChange(Player paramPlayer)
  {
    return false;
  }

  public boolean onComplexBlockChange(Player paramPlayer, ComplexBlock paramComplexBlock)
  {
    return false;
  }

  public boolean onSendComplexBlock(Player paramPlayer, ComplexBlock paramComplexBlock)
  {
    return false;
  }

  public static enum Priority
  {
    CRITICAL, HIGH, MEDIUM, LOW;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     PluginListener
 * JD-Core Version:    0.6.0
 */