import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;

public abstract class DataSource
{
  protected static final Logger log = Logger.getLogger("Minecraft");
  protected List<String> reserveList;
  protected List<String> whiteList;
  protected List<Group> groups;
  protected List<Kit> kits;
  protected List<Warp> homes;
  protected List<Warp> warps;
  protected List<Ban> bans;
  protected Map<String, Integer> items;
  protected MinecraftServer server;
  protected final Object groupLock = new Object();
  protected final Object kitLock = new Object();
  protected final Object banLock = new Object();
  protected final Object homeLock = new Object();
  protected final Object warpLock = new Object();
  protected final Object itemLock = new Object();
  protected final Object whiteListLock = new Object();
  protected final Object reserveListLock = new Object();

  public abstract void initialize();

  public abstract void loadGroups();

  public abstract void loadKits();

  public abstract void loadHomes();

  public abstract void loadWarps();

  public abstract void loadItems();

  public abstract void loadWhitelist();

  public abstract void loadReserveList();

  public abstract void loadBanList();

  public abstract void addPlayer(Player paramPlayer);

  public abstract void modifyPlayer(Player paramPlayer);

  public abstract boolean doesPlayerExist(String paramString);

  public abstract Player getPlayer(String paramString);

  public abstract void addGroup(Group paramGroup);

  public abstract void modifyGroup(Group paramGroup);

  public Group getGroup(String paramString)
  {
    synchronized (this.groupLock)
    {
      Iterator localIterator = this.groups.iterator();
      while (localIterator.hasNext())
      {
        Group localGroup = (Group)localIterator.next();
        if (localGroup.Name.equalsIgnoreCase(paramString))
          return localGroup;
      }
    }
    if (!paramString.equals(""))
      log.log(Level.INFO, new StringBuilder().append("Unable to find group '").append(paramString).append("'. Are you sure you have that group?").toString());
    return null;
  }

  public Group getDefaultGroup()
  {
    synchronized (this.groupLock)
    {
      Iterator localIterator = this.groups.iterator();
      while (localIterator.hasNext())
      {
        Group localGroup = (Group)localIterator.next();
        if (localGroup.DefaultGroup)
          return localGroup;
      }
    }
    return null;
  }

  public abstract void addKit(Kit paramKit);

  public abstract void modifyKit(Kit paramKit);

  public Kit getKit(String paramString)
  {
    synchronized (this.kitLock)
    {
      Iterator localIterator = this.kits.iterator();
      while (localIterator.hasNext())
      {
        Kit localKit = (Kit)localIterator.next();
        if (localKit.Name.equalsIgnoreCase(paramString))
          return localKit;
      }
    }
    return null;
  }

  public boolean hasKits()
  {
    synchronized (this.kitLock)
    {
      return this.kits.size() > 0;
    }
  }

  public String getKitNames(Player paramPlayer)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("");
    synchronized (this.kitLock)
    {
      Iterator localIterator = this.kits.iterator();
      while (localIterator.hasNext())
      {
        Kit localKit = (Kit)localIterator.next();
        if ((paramPlayer.isInGroup(localKit.Group)) || (localKit.Group.equals("")))
          localStringBuilder.append(localKit.Name).append(" ");
      }
    }
    return localStringBuilder.toString();
  }

  public abstract void addHome(Warp paramWarp);

  public abstract void changeHome(Warp paramWarp);

  public Warp getHome(String paramString)
  {
    synchronized (this.homeLock)
    {
      Iterator localIterator = this.homes.iterator();
      while (localIterator.hasNext())
      {
        Warp localWarp = (Warp)localIterator.next();
        if (localWarp.Name.equalsIgnoreCase(paramString))
          return localWarp;
      }
    }
    return null;
  }

  public abstract void addWarp(Warp paramWarp);

  public abstract void changeWarp(Warp paramWarp);

  public abstract void removeWarp(Warp paramWarp);

  public Warp getWarp(String paramString)
  {
    synchronized (this.warpLock)
    {
      Iterator localIterator = this.warps.iterator();
      while (localIterator.hasNext())
      {
        Warp localWarp = (Warp)localIterator.next();
        if (localWarp.Name.equalsIgnoreCase(paramString))
          return localWarp;
      }
    }
    return null;
  }

  public boolean hasWarps()
  {
    synchronized (this.warpLock)
    {
      return this.warps.size() > 0;
    }
  }

  public String getWarpNames(Player paramPlayer)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("");
    synchronized (this.warpLock)
    {
      Iterator localIterator = this.warps.iterator();
      while (localIterator.hasNext())
      {
        Warp localWarp = (Warp)localIterator.next();
        if ((paramPlayer.isInGroup(localWarp.Group)) || (localWarp.Group.equals("")))
          localStringBuilder.append(localWarp.Name).append(" ");
      }
    }
    return localStringBuilder.toString();
  }

  public int getItem(String paramString)
  {
    synchronized (this.itemLock)
    {
      if (this.items.containsKey(paramString))
        return ((Integer)this.items.get(paramString)).intValue();
    }
    return 0;
  }

  public String getItem(int paramInt)
  {
    synchronized (this.itemLock)
    {
      Iterator localIterator = this.items.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (((Integer)this.items.get(str)).intValue() == paramInt)
          return str;
      }
    }
    return String.valueOf(paramInt);
  }

  public Map<String, Integer> getItems()
  {
    return Collections.unmodifiableMap(this.items);
  }

  public abstract void addToWhitelist(String paramString);

  public abstract void removeFromWhitelist(String paramString);

  public boolean hasWhitelist()
  {
    synchronized (this.whiteListLock)
    {
      return !this.whiteList.isEmpty();
    }
  }

  public boolean isUserOnWhitelist(String paramString)
  {
    synchronized (this.whiteListLock)
    {
      Iterator localIterator = this.whiteList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (str.equalsIgnoreCase(paramString))
          return true;
      }
    }
    return false;
  }

  public abstract void addToReserveList(String paramString);

  public abstract void removeFromReserveList(String paramString);

  public boolean hasReserveList()
  {
    synchronized (this.reserveListLock)
    {
      return !this.reserveList.isEmpty();
    }
  }

  public boolean isUserOnReserveList(String paramString)
  {
    synchronized (this.reserveListLock)
    {
      Iterator localIterator = this.reserveList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (str.equalsIgnoreCase(paramString))
          return true;
      }
    }
    return false;
  }

  public abstract void modifyBan(Ban paramBan);

  public boolean isOnBanList(String paramString1, String paramString2)
  {
    synchronized (this.banLock)
    {
      Iterator localIterator = this.bans.iterator();
      while (localIterator.hasNext())
      {
        Ban localBan = (Ban)localIterator.next();
        if ((localBan.getName().equalsIgnoreCase(paramString1)) || (localBan.getIp().equalsIgnoreCase(paramString2)))
          return true;
      }
    }
    return false;
  }

  public Ban getBan(String paramString1, String paramString2)
  {
    synchronized (this.banLock)
    {
      Iterator localIterator = this.bans.iterator();
      while (localIterator.hasNext())
      {
        Ban localBan = (Ban)localIterator.next();
        if ((localBan.getName().equalsIgnoreCase(paramString1)) || (localBan.getIp().equalsIgnoreCase(paramString2)))
          return localBan;
      }
    }
    return null;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     DataSource
 * JD-Core Version:    0.6.0
 */