import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class as
{
  private static Map e = new HashMap();
  private static Map f = new HashMap();
  public dy a;
  public int b;
  public int c;
  public int d;

  private static void a(Class paramClass, String paramString)
  {
    if (f.containsKey(paramString))
      throw new IllegalArgumentException("Duplicate id: " + paramString);
    e.put(paramString, paramClass);
    f.put(paramClass, paramString);
  }

  public void a(s params)
  {
    this.b = params.d("x");
    this.c = params.d("y");
    this.d = params.d("z");
  }

  public void b(s params)
  {
    String str = (String)f.get(getClass());
    if (str == null)
      throw new RuntimeException(getClass() + " is missing a mapping! This is a bug!");
    params.a("id", str);
    params.a("x", this.b);
    params.a("y", this.c);
    params.a("z", this.d);
  }

  public void b()
  {
  }

  public static as c(s params)
  {
    as localas = null;
    try
    {
      Class localClass = (Class)e.get(params.h("id"));
      if (localClass != null)
        localas = (as)localClass.newInstance();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    if (localas != null)
      localas.a(params);
    else
      System.out.println("Skipping TileEntity with id " + params.h("id"));
    return localas;
  }

  public void c()
  {
    Iterator localIterator = etc.getServer().getPlayerList().iterator();
    while (localIterator.hasNext())
    {
      Player localPlayer = (Player)localIterator.next();
      as localas = this;
      Object localObject1 = null;
      if ((localas instanceof hb))
        localObject1 = new Chest((hb)localas);
      else if ((localas instanceof df))
        localObject1 = new Furnace((df)localas);
      else if ((localas instanceof ig))
        localObject1 = new Sign((ig)localas);
      if (localObject1 != null)
      {
        if (!((Boolean)etc.getLoader().callHook(PluginLoader.Hook.COMPLEX_BLOCK_SEND, new Object[] { localPlayer.getUser(), localObject1 })).booleanValue())
        {
          localPlayer.getUser().a.b.a(new ib(this.b, this.c, this.d, this));
        }
        else
        {
          Object localObject2 = null;
          if ((localas instanceof hb))
            localObject2 = new hb();
          else if ((localas instanceof df))
            localObject2 = new df();
          else if ((localas instanceof ig))
            localObject2 = new ig();
          ((as)localObject2).b = this.b;
          ((as)localObject2).c = this.c;
          ((as)localObject2).d = this.d;
          localPlayer.getUser().a.b.a(new ib(this.b, this.c, this.d, (as)localObject2));
        }
      }
      else
        localPlayer.getUser().a.b.a(new ib(this.b, this.c, this.d, this));
    }
  }

  static
  {
    a(df.class, "Furnace");
    a(hb.class, "Chest");
    a(ig.class, "Sign");
    a(bs.class, "MobSpawner");
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     as
 * JD-Core Version:    0.6.0
 */