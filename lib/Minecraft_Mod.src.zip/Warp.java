public class Warp
{
  public int ID;
  public String Name;
  public String Group;
  public Location Location;
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Warp
 * JD-Core Version:    0.6.0
 */