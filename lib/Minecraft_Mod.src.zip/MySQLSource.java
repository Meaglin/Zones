import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MySQLSource extends DataSource
{
  private String driver;
  private String username;
  private String password;
  private String db;

  private Connection getConnection()
  {
    try
    {
      return DriverManager.getConnection(this.db + "?autoReconnect=true&user=" + this.username + "&password=" + this.password);
    }
    catch (SQLException localSQLException)
    {
      log.log(Level.SEVERE, "Unable to retreive connection", localSQLException);
    }
    return null;
  }

  public void initialize()
  {
    PropertiesFile localPropertiesFile = new PropertiesFile("mysql.properties");
    this.driver = localPropertiesFile.getString("driver", "com.mysql.jdbc.Driver");
    this.username = localPropertiesFile.getString("user", "root");
    this.password = localPropertiesFile.getString("pass", "root");
    this.db = localPropertiesFile.getString("db", "jdbc:mysql://localhost:3306/minecraft");
    try
    {
      Class.forName(this.driver);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      log.log(Level.SEVERE, "Unable to find class " + this.driver, localClassNotFoundException);
    }
    loadGroups();
    loadKits();
    loadHomes();
    loadWarps();
    loadItems();
    loadWhitelist();
    loadReserveList();
  }

  public void loadGroups()
  {
    synchronized (this.groupLock)
    {
      this.groups = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM groups");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
        {
          Group localGroup = new Group();
          localGroup.Administrator = localResultSet.getBoolean("admin");
          localGroup.CanModifyWorld = localResultSet.getBoolean("canmodifyworld");
          localGroup.Commands = localResultSet.getString("commands").split(",");
          localGroup.DefaultGroup = localResultSet.getBoolean("defaultgroup");
          localGroup.ID = localResultSet.getInt("id");
          localGroup.IgnoreRestrictions = localResultSet.getBoolean("ignoresrestrictions");
          localGroup.InheritedGroups = localResultSet.getString("inheritedgroups").split(",");
          localGroup.Name = localResultSet.getString("name");
          localGroup.Prefix = localResultSet.getString("prefix");
          if ((localGroup.InheritedGroups.length == 1) && (localGroup.InheritedGroups[0].equalsIgnoreCase(localGroup.Name)))
            localGroup.InheritedGroups = new String[] { "" };
          this.groups.add(localGroup);
        }
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive groups from group table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadKits()
  {
    synchronized (this.kitLock)
    {
      this.kits = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM kits");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
        {
          Kit localKit = new Kit();
          localKit.Delay = localResultSet.getInt("delay");
          localKit.Group = localResultSet.getString("group");
          localKit.ID = localResultSet.getInt("id");
          localKit.Name = localResultSet.getString("name");
          localKit.IDs = new HashMap();
          String[] arrayOfString1 = localResultSet.getString("items").split(",");
          for (String str1 : arrayOfString1)
          {
            String str2 = "";
            int k = 1;
            if (str1.contains(" "))
            {
              str2 = str1.split(" ")[0];
              k = Integer.parseInt(str1.split(" ")[1]);
            }
            else
            {
              str2 = str1;
            }
            localKit.IDs.put(str2, Integer.valueOf(k));
          }
          this.kits.add(localKit);
        }
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive kits from kit table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadHomes()
  {
    synchronized (this.homeLock)
    {
      this.homes = new ArrayList();
      if (!etc.getInstance().canSaveHomes())
        return;
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM homes");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
        {
          Location localLocation = new Location();
          localLocation.x = localResultSet.getDouble("x");
          localLocation.y = localResultSet.getDouble("y");
          localLocation.z = localResultSet.getDouble("z");
          localLocation.rotX = localResultSet.getFloat("rotX");
          localLocation.rotY = localResultSet.getFloat("rotY");
          Warp localWarp = new Warp();
          localWarp.ID = localResultSet.getInt("id");
          localWarp.Location = localLocation;
          localWarp.Name = localResultSet.getString("name");
          localWarp.Group = localResultSet.getString("group");
          this.homes.add(localWarp);
        }
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive homes from home table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadWarps()
  {
    synchronized (this.warpLock)
    {
      this.warps = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM warps");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
        {
          Location localLocation = new Location();
          localLocation.x = localResultSet.getDouble("x");
          localLocation.y = localResultSet.getDouble("y");
          localLocation.z = localResultSet.getDouble("z");
          localLocation.rotX = localResultSet.getFloat("rotX");
          localLocation.rotY = localResultSet.getFloat("rotY");
          Warp localWarp = new Warp();
          localWarp.ID = localResultSet.getInt("id");
          localWarp.Location = localLocation;
          localWarp.Name = localResultSet.getString("name");
          localWarp.Group = localResultSet.getString("group");
          this.warps.add(localWarp);
        }
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive warps from warp table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadItems()
  {
    synchronized (this.itemLock)
    {
      this.items = new HashMap();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM items");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
          this.items.put(localResultSet.getString("name"), Integer.valueOf(localResultSet.getInt("itemid")));
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive items from item table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadWhitelist()
  {
    synchronized (this.whiteListLock)
    {
      this.whiteList = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM whitelist");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
          this.whiteList.add(localResultSet.getString(1));
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive users from whitelist table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void loadReserveList()
  {
    synchronized (this.reserveListLock)
    {
      this.reserveList = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM reservelist");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
          this.reserveList.add(localResultSet.getString(1));
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive users from whitelist table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void addPlayer(Player paramPlayer)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("INSERT INTO users (name, groups, prefix, commands, admin, canmodifyworld, ignoresrestrictions) VALUES (?,?,?,?,?,?,?)", 1);
      localPreparedStatement.setString(1, paramPlayer.getName());
      localPreparedStatement.setString(2, etc.combineSplit(0, paramPlayer.getGroups(), ","));
      localPreparedStatement.setString(3, paramPlayer.getPrefix());
      localPreparedStatement.setString(4, etc.combineSplit(0, paramPlayer.getCommands(), ","));
      localPreparedStatement.setBoolean(5, paramPlayer.getAdmin());
      localPreparedStatement.setBoolean(6, paramPlayer.canModifyWorld());
      localPreparedStatement.setBoolean(7, paramPlayer.ignoreRestrictions());
      localPreparedStatement.executeUpdate();
      localResultSet = localPreparedStatement.getGeneratedKeys();
      if (localResultSet.next())
        paramPlayer.setSqlId(localResultSet.getInt(1));
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to insert user into users table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localResultSet != null)
          localResultSet.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void modifyPlayer(Player paramPlayer)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("UPDATE users SET groups = ?, prefix = ?, commands = ?, admin = ?, canmodifyworld = ?, ignoresrestrictions = ? WHERE id = ?");
      localPreparedStatement.setString(1, etc.combineSplit(0, paramPlayer.getGroups(), ","));
      localPreparedStatement.setString(2, paramPlayer.getPrefix());
      localPreparedStatement.setString(3, etc.combineSplit(0, paramPlayer.getCommands(), ","));
      localPreparedStatement.setBoolean(4, paramPlayer.getAdmin());
      localPreparedStatement.setBoolean(5, paramPlayer.canModifyWorld());
      localPreparedStatement.setBoolean(6, paramPlayer.ignoreRestrictions());
      localPreparedStatement.setInt(7, paramPlayer.getSqlId());
      localPreparedStatement.executeUpdate();
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update user in users table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public boolean doesPlayerExist(String paramString)
  {
    int i = 0;
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("SELECT * FROM users WHERE name = ?");
      localPreparedStatement.setString(1, paramString);
      localResultSet = localPreparedStatement.executeQuery();
      if (localResultSet.next())
        i = 1;
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to check if user exists", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localResultSet != null)
          localResultSet.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
    return i;
  }

  public void addGroup(Group paramGroup)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void modifyGroup(Group paramGroup)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addKit(Kit paramKit)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void modifyKit(Kit paramKit)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addHome(Warp paramWarp)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("INSERT INTO homes (name, x, y, z, rotX, rotY, `group`) VALUES(?, ?, ?, ?, ?, ?, ?)", 1);
      localPreparedStatement.setString(1, paramWarp.Name);
      localPreparedStatement.setDouble(2, paramWarp.Location.x);
      localPreparedStatement.setDouble(3, paramWarp.Location.y);
      localPreparedStatement.setDouble(4, paramWarp.Location.z);
      localPreparedStatement.setFloat(5, paramWarp.Location.rotX);
      localPreparedStatement.setFloat(6, paramWarp.Location.rotY);
      localPreparedStatement.setString(7, paramWarp.Group);
      localPreparedStatement.executeUpdate();
      localResultSet = localPreparedStatement.getGeneratedKeys();
      if (localResultSet.next())
      {
        paramWarp.ID = localResultSet.getInt(1);
        synchronized (this.homeLock)
        {
          this.homes.add(paramWarp);
        }
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to insert home into homes table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localResultSet != null)
          localResultSet.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void changeHome(Warp paramWarp)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("UPDATE homes SET x = ?, y = ?, z = ?, rotX = ?, rotY = ?, `group` = ? WHERE name = ?");
      localPreparedStatement.setDouble(1, paramWarp.Location.x);
      localPreparedStatement.setDouble(2, paramWarp.Location.y);
      localPreparedStatement.setDouble(3, paramWarp.Location.z);
      localPreparedStatement.setFloat(4, paramWarp.Location.rotX);
      localPreparedStatement.setFloat(5, paramWarp.Location.rotY);
      localPreparedStatement.setString(6, paramWarp.Group);
      localPreparedStatement.setString(7, paramWarp.Name);
      localPreparedStatement.executeUpdate();
      synchronized (this.homeLock)
      {
        Object localObject1 = null;
        Iterator localIterator = this.homes.iterator();
        while (localIterator.hasNext())
        {
          Warp localWarp = (Warp)localIterator.next();
          if (localWarp.Name.equalsIgnoreCase(paramWarp.Name))
            localObject1 = localWarp;
        }
        if (localObject1 != null)
          this.homes.remove(localObject1);
        this.homes.add(paramWarp);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update home in homes table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void addWarp(Warp paramWarp)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("INSERT INTO warps (name, x, y, z, rotX, rotY, `group`) VALUES(?, ?, ?, ?, ?, ?, ?)", 1);
      localPreparedStatement.setString(1, paramWarp.Name);
      localPreparedStatement.setDouble(2, paramWarp.Location.x);
      localPreparedStatement.setDouble(3, paramWarp.Location.y);
      localPreparedStatement.setDouble(4, paramWarp.Location.z);
      localPreparedStatement.setFloat(5, paramWarp.Location.rotX);
      localPreparedStatement.setFloat(6, paramWarp.Location.rotY);
      localPreparedStatement.setString(7, paramWarp.Group);
      localPreparedStatement.executeUpdate();
      localResultSet = localPreparedStatement.getGeneratedKeys();
      if (localResultSet.next())
      {
        paramWarp.ID = localResultSet.getInt(1);
        synchronized (this.warpLock)
        {
          this.warps.add(paramWarp);
        }
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to insert warp into warps table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localResultSet != null)
          localResultSet.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void changeWarp(Warp paramWarp)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("UPDATE warps SET x = ?, y = ?, z = ?, rotX = ?, rotY = ?, `group` = ? WHERE name = ?");
      localPreparedStatement.setDouble(1, paramWarp.Location.x);
      localPreparedStatement.setDouble(2, paramWarp.Location.y);
      localPreparedStatement.setDouble(3, paramWarp.Location.z);
      localPreparedStatement.setFloat(4, paramWarp.Location.rotX);
      localPreparedStatement.setFloat(5, paramWarp.Location.rotY);
      localPreparedStatement.setString(6, paramWarp.Group);
      localPreparedStatement.setString(7, paramWarp.Name);
      localPreparedStatement.executeUpdate();
      synchronized (this.warpLock)
      {
        Object localObject1 = null;
        Iterator localIterator = this.warps.iterator();
        while (localIterator.hasNext())
        {
          Warp localWarp = (Warp)localIterator.next();
          if (localWarp.Name.equalsIgnoreCase(paramWarp.Name))
            localObject1 = localWarp;
        }
        if (localObject1 != null)
          this.warps.remove(localObject1);
        this.warps.add(paramWarp);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update warp in warps table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void removeWarp(Warp paramWarp)
  {
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("DELETE FROM warps WHERE id = ?");
      localPreparedStatement.setDouble(1, paramWarp.ID);
      localPreparedStatement.executeUpdate();
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to delete warp from warps table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
    synchronized (this.warpLock)
    {
      this.warps.remove(paramWarp);
    }
  }

  public void addToWhitelist(String paramString)
  {
    if (isUserOnWhitelist(paramString))
      return;
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("INSERT INTO whitelist VALUES(?)");
      localPreparedStatement.setString(1, paramString);
      localPreparedStatement.executeUpdate();
      synchronized (this.whiteListLock)
      {
        this.whiteList.add(paramString);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update whitelist", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void removeFromWhitelist(String paramString)
  {
    if (!isUserOnWhitelist(paramString))
      return;
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("DELETE FROM whitelist WHERE name = ?");
      localPreparedStatement.setString(1, paramString);
      localPreparedStatement.executeUpdate();
      synchronized (this.whiteListLock)
      {
        this.whiteList.add(paramString);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update whitelist", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void addToReserveList(String paramString)
  {
    if (isUserOnReserveList(paramString))
      return;
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("INSERT INTO reservelist VALUES(?)");
      localPreparedStatement.setString(1, paramString);
      localPreparedStatement.executeUpdate();
      synchronized (this.reserveListLock)
      {
        this.reserveList.add(paramString);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update reservelist", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public void removeFromReserveList(String paramString)
  {
    if (!isUserOnReserveList(paramString))
      return;
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("DELETE FROM reservelist WHERE name = ?");
      localPreparedStatement.setString(1, paramString);
      localPreparedStatement.executeUpdate();
      synchronized (this.reserveListLock)
      {
        this.reserveList.add(paramString);
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to update reservelist", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
  }

  public Player getPlayer(String paramString)
  {
    Player localPlayer = new Player();
    Connection localConnection = null;
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localConnection = getConnection();
      localPreparedStatement = localConnection.prepareStatement("SELECT * FROM users WHERE name = ?");
      localPreparedStatement.setString(1, paramString);
      localResultSet = localPreparedStatement.executeQuery();
      if (localResultSet.next())
      {
        localPlayer.setSqlId(localResultSet.getInt("id"));
        localPlayer.setGroups(localResultSet.getString("groups").split(","));
        localPlayer.setCommands(localResultSet.getString("commands").split(","));
        localPlayer.setPrefix(localResultSet.getString("prefix"));
        localPlayer.setAdmin(localResultSet.getBoolean("admin"));
        localPlayer.setCanModifyWorld(localResultSet.getBoolean("canmodifyworld"));
        localPlayer.setIgnoreRestrictions(localResultSet.getBoolean("ignoresrestrictions"));
        localPlayer.setIps(localResultSet.getString("ip").split(","));
      }
    }
    catch (SQLException localSQLException3)
    {
      log.log(Level.SEVERE, "Unable to retreive users from user table", localSQLException2);
    }
    finally
    {
      try
      {
        if (localPreparedStatement != null)
          localPreparedStatement.close();
        if (localResultSet != null)
          localResultSet.close();
        if (localConnection != null)
          localConnection.close();
      }
      catch (SQLException localSQLException4)
      {
      }
    }
    return localPlayer;
  }

  public void loadBanList()
  {
    synchronized (this.banLock)
    {
      this.bans = new ArrayList();
      Connection localConnection = null;
      PreparedStatement localPreparedStatement = null;
      ResultSet localResultSet = null;
      try
      {
        localConnection = getConnection();
        localPreparedStatement = localConnection.prepareStatement("SELECT * FROM bans");
        localResultSet = localPreparedStatement.executeQuery();
        while (localResultSet.next())
        {
          Ban localBan = new Ban();
          localBan.setName(localResultSet.getString("name"));
          localBan.setIp(localResultSet.getString("ip"));
          localBan.setReason(localResultSet.getString("reason"));
          localBan.setTimestamp(localResultSet.getInt("length"));
          this.bans.add(localBan);
        }
      }
      catch (SQLException localSQLException3)
      {
        log.log(Level.SEVERE, "Unable to retreive bans from ban table", localSQLException2);
      }
      finally
      {
        try
        {
          if (localPreparedStatement != null)
            localPreparedStatement.close();
          if (localResultSet != null)
            localResultSet.close();
          if (localConnection != null)
            localConnection.close();
        }
        catch (SQLException localSQLException4)
        {
        }
      }
    }
  }

  public void modifyBan(Ban paramBan)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     MySQLSource
 * JD-Core Version:    0.6.0
 */