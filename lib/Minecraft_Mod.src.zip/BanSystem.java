public class BanSystem
{
  public void fileBan(Player paramPlayer)
  {
  }

  public void fileIpBan(Player paramPlayer)
  {
  }

  public void fileTempBan(Player paramPlayer, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = (int)(System.currentTimeMillis() / 1000L);
    i += paramInt1 * 60;
    i += paramInt2 * 60 * 60;
    i += paramInt3 * 60 * 60 * 24;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     BanSystem
 * JD-Core Version:    0.6.0
 */