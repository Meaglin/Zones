public class PluginRegisteredListener
{
  private PluginLoader.Hook hook;
  private PluginListener listener;
  private Plugin plugin;
  private int priority;

  public PluginRegisteredListener(PluginLoader.Hook paramHook, PluginListener paramPluginListener, Plugin paramPlugin, int paramInt)
  {
    this.hook = paramHook;
    this.listener = paramPluginListener;
    this.plugin = paramPlugin;
    this.priority = paramInt;
  }

  public PluginLoader.Hook getHook()
  {
    return this.hook;
  }

  public PluginListener getListener()
  {
    return this.listener;
  }

  public Plugin getPlugin()
  {
    return this.plugin;
  }

  public int getPriority()
  {
    return this.priority;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     PluginRegisteredListener
 * JD-Core Version:    0.6.0
 */