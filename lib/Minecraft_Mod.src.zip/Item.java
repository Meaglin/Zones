public class Item
{
  private int itemId = 1;
  private int amount = 1;
  private int slot = -1;

  public Item()
  {
  }

  public Item(int paramInt1, int paramInt2)
  {
    this.itemId = paramInt1;
    this.amount = paramInt2;
  }

  public Item(int paramInt1, int paramInt2, int paramInt3)
  {
    this.itemId = paramInt1;
    this.amount = paramInt2;
    this.slot = paramInt3;
  }

  public int getItemId()
  {
    return this.itemId;
  }

  public void setItemId(int paramInt)
  {
    this.itemId = paramInt;
  }

  public int getAmount()
  {
    return this.amount;
  }

  public void setAmount(int paramInt)
  {
    this.amount = paramInt;
  }

  public static boolean isValidItem(int paramInt)
  {
    if (paramInt < ez.c.length)
      return ez.c[paramInt] != null;
    return false;
  }

  public int getSlot()
  {
    return this.slot;
  }

  public void setSlot(int paramInt)
  {
    this.slot = paramInt;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Item
 * JD-Core Version:    0.6.0
 */