public class Inventory extends ItemArray
{
  private ea user;
  private Inventory.Type type;

  public Inventory(Player paramPlayer, Inventory.Type paramType)
  {
    this.user = paramPlayer.getUser();
    this.type = paramType;
  }

  public void giveItem(int paramInt1, int paramInt2)
  {
    if (paramInt2 == -1)
    {
      i = getEmptySlot();
      if (i == -1)
        this.user.getPlayer().giveItemDrop(paramInt1, -1);
      else
        addItem(new Item(paramInt1, 255, i));
      return;
    }
    int i = paramInt2;
    do
    {
      int j = i >= 64 ? 64 : i;
      if (hasItem(paramInt1, 1, 63))
      {
        Item localItem = getItemFromId(paramInt1, 63);
        if (localItem != null)
        {
          int m;
          if (j == 64)
          {
            m = j - localItem.getAmount();
            localItem.setAmount(64);
            i -= m;
          }
          else if (j + localItem.getAmount() > 64)
          {
            m = j + localItem.getAmount() - 64;
            localItem.setAmount(64);
            i = m;
          }
          else if (j + localItem.getAmount() <= 64)
          {
            localItem.setAmount(j + localItem.getAmount());
            i = 0;
          }
          addItem(localItem);
          continue;
        }
      }
      int k = getEmptySlot();
      if (k == -1)
        break;
      addItem(new Item(paramInt1, j, k));
      i -= 64;
    }
    while (i > 0);
    if (i > 0)
      this.user.getPlayer().giveItemDrop(paramInt1, i);
  }

  public void updateInventory()
  {
    this.user.a.d();
  }

  public gp[] getArray()
  {
    switch (Inventory.1.$SwitchMap$Inventory$Type[this.type.ordinal()])
    {
    case 1:
      return this.user.aj.a;
    case 2:
      return this.user.aj.c;
    case 3:
      return this.user.aj.b;
    }
    return new gp[0];
  }

  public static enum Type
  {
    Inventory, CraftingTable, Equipment;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Inventory
 * JD-Core Version:    0.6.0
 */