import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FlatFileSource extends DataSource
{
  public void initialize()
  {
    loadGroups();
    loadKits();
    loadHomes();
    loadWarps();
    loadItems();
    loadWhitelist();
    loadReserveList();
    String str = etc.getInstance().getUsersLocation();
    if (!new File(str).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str);
        localFileWriter.write("#Add your users here (When adding your entry DO NOT include #!)\r\n");
        localFileWriter.write("#The format is:\r\n");
        localFileWriter.write("#NAME:GROUPS:ADMIN/UNRESTRICTED:COLOR:COMMANDS:IPs\r\n");
        localFileWriter.write("#For administrative powers set admin/unrestricted to 2.\r\n");
        localFileWriter.write("#For no restrictions and ability to give out items set it to 1.\r\n");
        localFileWriter.write("#If you don't want the person to be able to build set it to -1.\r\n");
        localFileWriter.write("#Admin/unrestricted, color and commands are optional.\r\n");
        localFileWriter.write("#Examples:\r\n");
        localFileWriter.write("#Adminfoo:admins\r\n");
        localFileWriter.write("#Moderator39:mods:1:0:/unban\r\n");
        localFileWriter.write("#BobTheBuilder:vip:0:d\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str).toString(), localException);
      }
      finally
      {
        try
        {
          if (localFileWriter != null)
            localFileWriter.close();
        }
        catch (IOException localIOException3)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while closing writer for ").append(str).toString(), localIOException3);
        }
      }
    }
  }

  public void loadGroups()
  {
    String str1 = etc.getInstance().getGroupLocation();
    if (!new File(str1).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str1);
        localFileWriter.write("#Add your groups here (When adding your entry DO NOT include #!)\r\n");
        localFileWriter.write("#The format is:\r\n");
        localFileWriter.write("#NAME:COLOR:COMMANDS:INHERITEDGROUPS:ADMIN/UNRESTRICTED\r\n");
        localFileWriter.write("#For administrative powers set admin/unrestricted to 2.\r\n");
        localFileWriter.write("#For no restrictions and ability to give out items set it to 1.\r\n");
        localFileWriter.write("#If you don't want the group to be able to build set it to -1.\r\n");
        localFileWriter.write("#Inherited groups and admin/unrestricted are optional.\r\n");
        localFileWriter.write("#Examples:\r\n");
        localFileWriter.write("admins:c:*:mods:2\r\n");
        localFileWriter.write("mods:b:/ban,/kick,/item,/tp,/tphere,/s,/i,/give:vip:1\r\n");
        localFileWriter.write("vip:a::default\r\n");
        localFileWriter.write("default:f:/help,/sethome,/home,/spawn,/me,/msg,/kit,/playerlist,/warp,/motd,/compass,/tell,/m,/who:default\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str1).toString(), localException1);
      }
      finally
      {
        try
        {
          if (localFileWriter != null)
            localFileWriter.close();
        }
        catch (IOException localIOException3)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while closing writer for ").append(str1).toString(), localIOException3);
        }
      }
    }
    synchronized (this.groupLock)
    {
      this.groups = new ArrayList();
      try
      {
        Scanner localScanner = new Scanner(new File(str1));
        while (localScanner.hasNextLine())
        {
          String str2 = localScanner.nextLine();
          if ((str2.startsWith("#")) || (str2.equals("")) || (str2.startsWith("﻿")))
            continue;
          String[] arrayOfString = str2.split(":");
          Group localGroup = new Group();
          localGroup.Name = arrayOfString[0];
          localGroup.Prefix = arrayOfString[1];
          localGroup.Commands = arrayOfString[2].split(",");
          if (arrayOfString.length >= 4)
            localGroup.InheritedGroups = arrayOfString[3].split(",");
          if (arrayOfString.length >= 5)
            if (arrayOfString[4].equals("1"))
              localGroup.IgnoreRestrictions = true;
            else if (arrayOfString[4].equals("2"))
              localGroup.Administrator = true;
            else if (arrayOfString[4].equals("-1"))
              localGroup.CanModifyWorld = false;
          if ((localGroup.InheritedGroups != null) && (localGroup.InheritedGroups[0].equalsIgnoreCase(localGroup.Name)))
          {
            localGroup.InheritedGroups = new String[] { "" };
            localGroup.DefaultGroup = true;
          }
          this.groups.add(localGroup);
        }
        localScanner.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).append(" (Are you sure you formatted it correctly?)").toString(), localException2);
      }
    }
  }

  public void loadKits()
  {
    String str1 = etc.getInstance().getKitsLocation();
    if (!new File(str1).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str1);
        localFileWriter.write("#Add your kits here. Example entry below (When adding your entry DO NOT include #!)\r\n");
        localFileWriter.write("#miningbasics:1,2,3,4:6000\r\n");
        localFileWriter.write(new StringBuilder().append("#The formats are (Find out more about groups in ").append(etc.getInstance().getUsersLocation()).append(":\r\n").toString());
        localFileWriter.write("#NAME:IDs:DELAY\r\n");
        localFileWriter.write("#NAME:IDs:DELAY:GROUP\r\n");
        localFileWriter.write("#6000 for delay is roughly 5 minutes.\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str1).toString(), localException1);
      }
      finally
      {
        try
        {
          if (localFileWriter != null)
            localFileWriter.close();
        }
        catch (IOException localIOException3)
        {
        }
      }
    }
    synchronized (this.kitLock)
    {
      this.kits = new ArrayList();
      try
      {
        Scanner localScanner = new Scanner(new File(str1));
        while (localScanner.hasNextLine())
        {
          String str2 = localScanner.nextLine();
          if ((str2.startsWith("#")) || (str2.equals("")))
            continue;
          String[] arrayOfString1 = str2.split(":");
          String str3 = arrayOfString1[0];
          String[] arrayOfString2 = arrayOfString1[1].split(",");
          int i = Integer.parseInt(arrayOfString1[2]);
          String str4 = "";
          if (arrayOfString1.length == 4)
            str4 = arrayOfString1[3];
          Kit localKit = new Kit();
          localKit.Name = str3;
          localKit.IDs = new HashMap();
          for (String str5 : arrayOfString2)
          {
            String str6 = "";
            int m = 1;
            if (str5.contains(" "))
            {
              str6 = str5.split(" ")[0];
              m = Integer.parseInt(str5.split(" ")[1]);
            }
            else
            {
              str6 = str5;
            }
            localKit.IDs.put(str6, Integer.valueOf(m));
          }
          localKit.Delay = i;
          localKit.Group = str4;
          this.kits.add(localKit);
        }
        localScanner.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).toString(), localException2);
      }
    }
  }

  public void loadHomes()
  {
    synchronized (this.homeLock)
    {
      this.homes = new ArrayList();
      if (!etc.getInstance().canSaveHomes())
        return;
      String str1 = etc.getInstance().getHomeLocation();
      if (new File(str1).exists())
        try
        {
          Scanner localScanner = new Scanner(new File(str1));
          while (localScanner.hasNextLine())
          {
            String str2 = localScanner.nextLine();
            if ((str2.startsWith("#")) || (str2.equals("")))
              continue;
            String[] arrayOfString = str2.split(":");
            if (arrayOfString.length < 4)
              continue;
            Location localLocation = new Location();
            localLocation.x = Double.parseDouble(arrayOfString[1]);
            localLocation.y = Double.parseDouble(arrayOfString[2]);
            localLocation.z = Double.parseDouble(arrayOfString[3]);
            if (arrayOfString.length >= 6)
            {
              localLocation.rotX = Float.parseFloat(arrayOfString[4]);
              localLocation.rotY = Float.parseFloat(arrayOfString[5]);
            }
            Warp localWarp = new Warp();
            localWarp.Name = arrayOfString[0];
            localWarp.Location = localLocation;
            if (arrayOfString.length >= 7)
              localWarp.Group = arrayOfString[6];
            else
              localWarp.Group = "";
            this.homes.add(localWarp);
          }
          localScanner.close();
        }
        catch (Exception localException)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).toString(), localException);
        }
    }
  }

  public void loadWarps()
  {
    synchronized (this.warpLock)
    {
      this.warps = new ArrayList();
      String str1 = etc.getInstance().getWarpLocation();
      if (new File(str1).exists())
        try
        {
          Scanner localScanner = new Scanner(new File(str1));
          while (localScanner.hasNextLine())
          {
            String str2 = localScanner.nextLine();
            if ((str2.startsWith("#")) || (str2.equals("")))
              continue;
            String[] arrayOfString = str2.split(":");
            if (arrayOfString.length < 4)
              continue;
            Location localLocation = new Location();
            localLocation.x = Double.parseDouble(arrayOfString[1]);
            localLocation.y = Double.parseDouble(arrayOfString[2]);
            localLocation.z = Double.parseDouble(arrayOfString[3]);
            if (arrayOfString.length == 6)
            {
              localLocation.rotX = Float.parseFloat(arrayOfString[4]);
              localLocation.rotY = Float.parseFloat(arrayOfString[5]);
            }
            Warp localWarp = new Warp();
            localWarp.Name = arrayOfString[0];
            localWarp.Location = localLocation;
            if (arrayOfString.length >= 7)
              localWarp.Group = arrayOfString[6];
            else
              localWarp.Group = "";
            this.warps.add(localWarp);
          }
          localScanner.close();
        }
        catch (Exception localException)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).toString(), localException);
        }
    }
  }

  public void loadItems()
  {
    String str1 = etc.getInstance().getItemLocation();
    if (!new File(str1).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str1);
        localFileWriter.write("#Add your items in here (When adding your entry DO NOT include #!)\r\n");
        localFileWriter.write("#The format is:\r\n");
        localFileWriter.write("#NAME:ID\r\n");
        localFileWriter.write("#Default Items:\r\n");
        localFileWriter.write("air:0\r\n");
        localFileWriter.write("rock:1\r\n");
        localFileWriter.write("grass:2\r\n");
        localFileWriter.write("dirt:3\r\n");
        localFileWriter.write("cobblestone:4\r\n");
        localFileWriter.write("wood:5\r\n");
        localFileWriter.write("sapling:6\r\n");
        localFileWriter.write("adminium:7\r\n");
        localFileWriter.write("water:8\r\n");
        localFileWriter.write("stillwater:9\r\n");
        localFileWriter.write("lava:10\r\n");
        localFileWriter.write("stilllava:11\r\n");
        localFileWriter.write("sand:12\r\n");
        localFileWriter.write("gravel:13\r\n");
        localFileWriter.write("goldore:14\r\n");
        localFileWriter.write("ironore:15\r\n");
        localFileWriter.write("coalore:16\r\n");
        localFileWriter.write("tree:17\r\n");
        localFileWriter.write("leaves:18\r\n");
        localFileWriter.write("sponge:19\r\n");
        localFileWriter.write("glass:20\r\n");
        localFileWriter.write("cloth:35\r\n");
        localFileWriter.write("flower:37\r\n");
        localFileWriter.write("rose:38\r\n");
        localFileWriter.write("brownmushroom:39\r\n");
        localFileWriter.write("redmushroom:40\r\n");
        localFileWriter.write("gold:41\r\n");
        localFileWriter.write("iron:42\r\n");
        localFileWriter.write("doublestair:43\r\n");
        localFileWriter.write("stair:44\r\n");
        localFileWriter.write("brick:45\r\n");
        localFileWriter.write("tnt:46\r\n");
        localFileWriter.write("bookshelf:47\r\n");
        localFileWriter.write("mossycobblestone:48\r\n");
        localFileWriter.write("obsidian:49\r\n");
        localFileWriter.write("torch:50\r\n");
        localFileWriter.write("fire:51\r\n");
        localFileWriter.write("mobspawner:52\r\n");
        localFileWriter.write("woodstairs:53\r\n");
        localFileWriter.write("chest:54\r\n");
        localFileWriter.write("redstonedust:55\r\n");
        localFileWriter.write("diamondore:56\r\n");
        localFileWriter.write("diamondblock:57\r\n");
        localFileWriter.write("workbench:58\r\n");
        localFileWriter.write("crop:59\r\n");
        localFileWriter.write("soil:60\r\n");
        localFileWriter.write("furnace:61\r\n");
        localFileWriter.write("litfurnace:62\r\n");
        localFileWriter.write("signblock:63\r\n");
        localFileWriter.write("wooddoorblock:64\r\n");
        localFileWriter.write("ladder:65\r\n");
        localFileWriter.write("rails:66\r\n");
        localFileWriter.write("cobblestonestairs:67\r\n");
        localFileWriter.write("signblocktop:68\r\n");
        localFileWriter.write("lever:69\r\n");
        localFileWriter.write("rockplate:70\r\n");
        localFileWriter.write("irondoorblock:71\r\n");
        localFileWriter.write("woodplate:72\r\n");
        localFileWriter.write("redstoneore:73\r\n");
        localFileWriter.write("redstoneorealt:74\r\n");
        localFileWriter.write("redstonetorchoff:75\r\n");
        localFileWriter.write("redstonetorchon:76\r\n");
        localFileWriter.write("button:77\r\n");
        localFileWriter.write("snow:78\r\n");
        localFileWriter.write("ice:79\r\n");
        localFileWriter.write("snowblock:80\r\n");
        localFileWriter.write("cactus:81\r\n");
        localFileWriter.write("clayblock:82\r\n");
        localFileWriter.write("reedblock:83\r\n");
        localFileWriter.write("jukebox:84\r\n");
        localFileWriter.write("fence:85\r\n");
        localFileWriter.write("ironshovel:256\r\n");
        localFileWriter.write("ironpickaxe:257\r\n");
        localFileWriter.write("ironaxe:258\r\n");
        localFileWriter.write("flintandsteel:259\r\n");
        localFileWriter.write("apple:260\r\n");
        localFileWriter.write("bow:261\r\n");
        localFileWriter.write("arrow:262\r\n");
        localFileWriter.write("coal:263\r\n");
        localFileWriter.write("diamond:264\r\n");
        localFileWriter.write("ironbar:265\r\n");
        localFileWriter.write("goldbar:266\r\n");
        localFileWriter.write("ironsword:267\r\n");
        localFileWriter.write("woodsword:268\r\n");
        localFileWriter.write("woodshovel:269\r\n");
        localFileWriter.write("woodpickaxe:270\r\n");
        localFileWriter.write("woodaxe:271\r\n");
        localFileWriter.write("stonesword:272\r\n");
        localFileWriter.write("stoneshovel:273\r\n");
        localFileWriter.write("stonepickaxe:274\r\n");
        localFileWriter.write("stoneaxe:275\r\n");
        localFileWriter.write("diamondsword:276\r\n");
        localFileWriter.write("diamondshovel:277\r\n");
        localFileWriter.write("diamondpickaxe:278\r\n");
        localFileWriter.write("diamondaxe:279\r\n");
        localFileWriter.write("stick:280\r\n");
        localFileWriter.write("bowl:281\r\n");
        localFileWriter.write("bowlwithsoup:282\r\n");
        localFileWriter.write("goldsword:283\r\n");
        localFileWriter.write("goldshovel:284\r\n");
        localFileWriter.write("goldpickaxe:285\r\n");
        localFileWriter.write("goldaxe:286\r\n");
        localFileWriter.write("string:287\r\n");
        localFileWriter.write("feather:288\r\n");
        localFileWriter.write("gunpowder:289\r\n");
        localFileWriter.write("woodhoe:290\r\n");
        localFileWriter.write("stonehoe:291\r\n");
        localFileWriter.write("ironhoe:292\r\n");
        localFileWriter.write("diamondhoe:293\r\n");
        localFileWriter.write("goldhoe:294\r\n");
        localFileWriter.write("seeds:295\r\n");
        localFileWriter.write("wheat:296\r\n");
        localFileWriter.write("bread:297\r\n");
        localFileWriter.write("leatherhelmet:298\r\n");
        localFileWriter.write("leatherchestplate:299\r\n");
        localFileWriter.write("leatherpants:300\r\n");
        localFileWriter.write("leatherboots:301\r\n");
        localFileWriter.write("chainmailhelmet:302\r\n");
        localFileWriter.write("chainmailchestplate:303\r\n");
        localFileWriter.write("chainmailpants:304\r\n");
        localFileWriter.write("chainmailboots:305\r\n");
        localFileWriter.write("ironhelmet:306\r\n");
        localFileWriter.write("ironchestplate:307\r\n");
        localFileWriter.write("ironpants:308\r\n");
        localFileWriter.write("ironboots:309\r\n");
        localFileWriter.write("diamondhelmet:310\r\n");
        localFileWriter.write("diamondchestplate:311\r\n");
        localFileWriter.write("diamondpants:312\r\n");
        localFileWriter.write("diamondboots:313\r\n");
        localFileWriter.write("goldhelmet:314\r\n");
        localFileWriter.write("goldchestplate:315\r\n");
        localFileWriter.write("goldpants:316\r\n");
        localFileWriter.write("goldboots:317\r\n");
        localFileWriter.write("flint:318\r\n");
        localFileWriter.write("meat:319\r\n");
        localFileWriter.write("cookedmeat:320\r\n");
        localFileWriter.write("painting:321\r\n");
        localFileWriter.write("goldenapple:322\r\n");
        localFileWriter.write("sign:323\r\n");
        localFileWriter.write("wooddoor:324\r\n");
        localFileWriter.write("bucket:325\r\n");
        localFileWriter.write("waterbucket:326\r\n");
        localFileWriter.write("lavabucket:327\r\n");
        localFileWriter.write("minecart:328\r\n");
        localFileWriter.write("saddle:329\r\n");
        localFileWriter.write("irondoor:330\r\n");
        localFileWriter.write("redstonedust:331\r\n");
        localFileWriter.write("snowball:332\r\n");
        localFileWriter.write("boat:333\r\n");
        localFileWriter.write("leather:334\r\n");
        localFileWriter.write("milkbucket:335\r\n");
        localFileWriter.write("brick:336\r\n");
        localFileWriter.write("clay:337\r\n");
        localFileWriter.write("reed:338\r\n");
        localFileWriter.write("paper:339\r\n");
        localFileWriter.write("book:340\r\n");
        localFileWriter.write("slimeorb:341\r\n");
        localFileWriter.write("storageminecart:342\r\n");
        localFileWriter.write("poweredminecart:343\r\n");
        localFileWriter.write("egg:344\r\n");
        localFileWriter.write("fishingrod:346\r\n");
        localFileWriter.write("rod:346\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str1).toString(), localException1);
      }
      finally
      {
        if (localFileWriter != null)
          try
          {
            localFileWriter.close();
          }
          catch (IOException localIOException3)
          {
            log.log(Level.SEVERE, new StringBuilder().append("Exception while closing writer for ").append(str1).toString(), localIOException3);
          }
      }
    }
    synchronized (this.itemLock)
    {
      this.items = new HashMap();
      try
      {
        Scanner localScanner = new Scanner(new File(str1));
        while (localScanner.hasNextLine())
        {
          String str2 = localScanner.nextLine();
          if ((str2.startsWith("#")) || (str2.equals("")))
            continue;
          String[] arrayOfString = str2.split(":");
          String str3 = arrayOfString[0];
          this.items.put(str3, Integer.valueOf(Integer.parseInt(arrayOfString[1])));
        }
        localScanner.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).append(" (Are you sure you formatted it correctly?)").toString(), localException2);
      }
    }
  }

  public void loadWhitelist()
  {
    String str1 = etc.getInstance().getWhitelistLocation();
    if (!new File(str1).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str1);
        localFileWriter.write("#Add your whitelisted users here (When adding your entry DO NOT include #!)\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str1).toString(), localException1);
      }
      finally
      {
        try
        {
          if (localFileWriter != null)
            localFileWriter.close();
        }
        catch (IOException localIOException3)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while closing writer for ").append(str1).toString(), localIOException3);
        }
      }
    }
    synchronized (this.whiteListLock)
    {
      this.whiteList = new ArrayList();
      try
      {
        Scanner localScanner = new Scanner(new File(str1));
        while (localScanner.hasNextLine())
        {
          String str2 = localScanner.nextLine();
          if ((str2.startsWith("#")) || (str2.equals("")))
            continue;
          this.whiteList.add(str2);
        }
        localScanner.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).toString(), localException2);
      }
    }
  }

  public void loadReserveList()
  {
    String str1 = etc.getInstance().getReservelistLocation();
    if (!new File(str1).exists())
    {
      FileWriter localFileWriter = null;
      try
      {
        localFileWriter = new FileWriter(str1);
        localFileWriter.write("#Add your reserve list users here (When adding your entry DO NOT include #!)\r\n");
      }
      catch (Exception localIOException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while creating ").append(str1).toString(), localException1);
      }
      finally
      {
        try
        {
          if (localFileWriter != null)
            localFileWriter.close();
        }
        catch (IOException localIOException3)
        {
          log.log(Level.SEVERE, new StringBuilder().append("Exception while closing writer for ").append(str1).toString(), localIOException3);
        }
      }
    }
    synchronized (this.reserveListLock)
    {
      this.reserveList = new ArrayList();
      try
      {
        Scanner localScanner = new Scanner(new File(str1));
        while (localScanner.hasNextLine())
        {
          String str2 = localScanner.nextLine();
          if ((str2.startsWith("#")) || (str2.equals("")))
            continue;
          this.reserveList.add(str2);
        }
        localScanner.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).toString(), localException2);
      }
    }
  }

  public void loadBanList()
  {
    synchronized (this.banLock)
    {
      this.bans = new ArrayList();
      String str;
      String[] arrayOfString;
      Ban localBan;
      try
      {
        Scanner localScanner1 = new Scanner(new File("banned-players.txt"));
        while (localScanner1.hasNextLine())
        {
          str = localScanner1.nextLine();
          if ((str.startsWith("#")) || (str.equals("")))
            continue;
          arrayOfString = str.split(":");
          localBan = new Ban();
          if (arrayOfString.length >= 1)
            localBan.setName(arrayOfString[0]);
          if (arrayOfString.length == 4)
          {
            localBan.setIp(arrayOfString[1]);
            localBan.setReason(arrayOfString[2]);
            localBan.setTimestamp(Integer.parseInt(arrayOfString[3]));
          }
          this.bans.add(localBan);
        }
        localScanner1.close();
      }
      catch (Exception localException1)
      {
        log.log(Level.SEVERE, "Exception while reading banned-players.txt", localException1);
      }
      try
      {
        Scanner localScanner2 = new Scanner(new File("banned-ips.txt"));
        while (localScanner2.hasNextLine())
        {
          str = localScanner2.nextLine();
          if ((str.startsWith("#")) || (str.equals("")))
            continue;
          arrayOfString = str.split(":");
          localBan = new Ban();
          if (arrayOfString.length >= 1)
            localBan.setIp(arrayOfString[0]);
          if (arrayOfString.length == 4)
          {
            localBan.setName(arrayOfString[1]);
            localBan.setReason(arrayOfString[2]);
            localBan.setTimestamp(Integer.parseInt(arrayOfString[3]));
          }
          this.bans.add(localBan);
        }
        localScanner2.close();
      }
      catch (Exception localException2)
      {
        log.log(Level.SEVERE, "Exception while reading banned-ips.txt", localException2);
      }
    }
  }

  public void addPlayer(Player paramPlayer)
  {
    String str = etc.getInstance().getUsersLocation();
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(str, true));
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramPlayer.getName());
      localStringBuilder.append(":");
      localStringBuilder.append(etc.combineSplit(0, paramPlayer.getGroups(), ","));
      localStringBuilder.append(":");
      if (paramPlayer.getAdmin())
        localStringBuilder.append("2");
      else if (paramPlayer.ignoreRestrictions())
        localStringBuilder.append("1");
      else if (!paramPlayer.canModifyWorld())
        localStringBuilder.append("-1");
      else
        localStringBuilder.append("0");
      localStringBuilder.append(":");
      localStringBuilder.append(paramPlayer.getPrefix());
      localStringBuilder.append(":");
      localStringBuilder.append(etc.combineSplit(0, paramPlayer.getCommands(), ","));
      localBufferedWriter.append(localStringBuilder.toString());
      localBufferedWriter.newLine();
      localBufferedWriter.close();
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while writing new user to ").append(str).toString(), localException);
    }
  }

  public void modifyPlayer(Player paramPlayer)
  {
    String str1 = etc.getInstance().getUsersLocation();
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(new File(str1)));
      StringBuilder localStringBuilder = new StringBuilder();
      String str2 = "";
      while ((str2 = localBufferedReader.readLine()) != null)
      {
        if (!str2.split(":")[0].equalsIgnoreCase(paramPlayer.getName()))
        {
          localStringBuilder.append(str2).append("\r\n");
          continue;
        }
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append(paramPlayer.getName());
        ((StringBuilder)localObject).append(":");
        ((StringBuilder)localObject).append(etc.combineSplit(0, paramPlayer.getGroups(), ","));
        ((StringBuilder)localObject).append(":");
        if (paramPlayer.getAdmin())
          ((StringBuilder)localObject).append("2");
        else if (paramPlayer.ignoreRestrictions())
          ((StringBuilder)localObject).append("1");
        else if (!paramPlayer.canModifyWorld())
          ((StringBuilder)localObject).append("-1");
        else
          ((StringBuilder)localObject).append("0");
        ((StringBuilder)localObject).append(":");
        ((StringBuilder)localObject).append(paramPlayer.getPrefix());
        ((StringBuilder)localObject).append(":");
        ((StringBuilder)localObject).append(etc.combineSplit(0, paramPlayer.getCommands(), ","));
        localStringBuilder.append(((StringBuilder)localObject).toString()).append("\r\n");
      }
      localBufferedReader.close();
      Object localObject = new FileWriter(str1);
      ((FileWriter)localObject).write(localStringBuilder.toString());
      ((FileWriter)localObject).close();
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while editing user in ").append(str1).toString(), localException);
    }
  }

  public boolean doesPlayerExist(String paramString)
  {
    String str1 = etc.getInstance().getUsersLocation();
    try
    {
      Scanner localScanner = new Scanner(new File(str1));
      while (localScanner.hasNextLine())
      {
        String str2 = localScanner.nextLine();
        if ((str2.startsWith("#")) || (str2.equals("")) || (str2.startsWith("﻿")))
          continue;
        String[] arrayOfString = str2.split(":");
        if (arrayOfString[0].equalsIgnoreCase(paramString))
          return true;
      }
      localScanner.close();
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).append(" (Are you sure you formatted it correctly?)").toString(), localException);
    }
    return false;
  }

  public Player getPlayer(String paramString)
  {
    Player localPlayer = new Player();
    String str1 = etc.getInstance().getUsersLocation();
    try
    {
      Scanner localScanner = new Scanner(new File(str1));
      while (localScanner.hasNextLine())
      {
        String str2 = localScanner.nextLine();
        if ((str2.startsWith("#")) || (str2.equals("")) || (str2.startsWith("﻿")))
          continue;
        String[] arrayOfString = str2.split(":");
        if (!arrayOfString[0].equalsIgnoreCase(paramString))
          continue;
        localPlayer.setGroups(arrayOfString[1].split(","));
        if (arrayOfString.length >= 3)
          if (arrayOfString[2].equals("1"))
            localPlayer.setIgnoreRestrictions(true);
          else if (arrayOfString[2].equals("2"))
            localPlayer.setAdmin(true);
          else if (arrayOfString[2].equals("-1"))
            localPlayer.setCanModifyWorld(false);
        if (arrayOfString.length >= 4)
          localPlayer.setPrefix(arrayOfString[3]);
        if (arrayOfString.length >= 5)
          localPlayer.setCommands(arrayOfString[4].split(","));
        if (arrayOfString.length >= 6)
          localPlayer.setIps(arrayOfString[5].split(","));
      }
      localScanner.close();
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while reading ").append(str1).append(" (Are you sure you formatted it correctly?)").toString(), localException);
    }
    return localPlayer;
  }

  public void addGroup(Group paramGroup)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void modifyGroup(Group paramGroup)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addKit(Kit paramKit)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void modifyKit(Kit paramKit)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addHome(Warp paramWarp)
  {
    String str = etc.getInstance().getHomeLocation();
    try
    {
      if (etc.getInstance().canSaveHomes())
      {
        BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(str, true));
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(paramWarp.Name);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.x);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.y);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.z);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.rotX);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.rotY);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Group);
        localBufferedWriter.append(localStringBuilder.toString());
        localBufferedWriter.newLine();
        localBufferedWriter.close();
      }
      synchronized (this.homeLock)
      {
        this.homes.add(paramWarp);
      }
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while writing new user home to ").append(str).toString(), localException);
    }
  }

  public void changeHome(Warp paramWarp)
  {
    Object localObject2;
    Object localObject3;
    synchronized (this.homeLock)
    {
      localObject1 = null;
      localObject2 = this.homes.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Warp)((Iterator)localObject2).next();
        if (((Warp)localObject3).Name.equalsIgnoreCase(paramWarp.Name))
          localObject1 = localObject3;
      }
      if (localObject1 != null)
        this.homes.remove(localObject1);
      this.homes.add(paramWarp);
    }
    ??? = null;
    Object localObject1 = etc.getInstance().getHomeLocation();
    try
    {
      if (etc.getInstance().canSaveHomes())
      {
        localObject2 = new BufferedReader(new FileReader(new File((String)localObject1)));
        localObject3 = new StringBuilder();
        String str = "";
        while ((str = ((BufferedReader)localObject2).readLine()) != null)
        {
          if (!str.split(":")[0].equalsIgnoreCase(paramWarp.Name))
          {
            ((StringBuilder)localObject3).append(str).append("\r\n");
            continue;
          }
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append(paramWarp.Name);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Location.x);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Location.y);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Location.z);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Location.rotX);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Location.rotY);
          localStringBuilder.append(":");
          localStringBuilder.append(paramWarp.Group);
          ((StringBuilder)localObject3).append(localStringBuilder.toString()).append("\r\n");
        }
        ((BufferedReader)localObject2).close();
        ??? = new FileWriter((String)localObject1);
        ((FileWriter)???).write(((StringBuilder)localObject3).toString());
        ((FileWriter)???).close();
      }
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while editing user home in ").append((String)localObject1).toString(), localException);
    }
    finally
    {
      try
      {
        if (??? != null)
          ((FileWriter)???).close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void addWarp(Warp paramWarp)
  {
    String str = etc.getInstance().getWarpLocation();
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(str, true));
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramWarp.Name);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Location.x);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Location.y);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Location.z);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Location.rotX);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Location.rotY);
      localStringBuilder.append(":");
      localStringBuilder.append(paramWarp.Group);
      localBufferedWriter.append(localStringBuilder.toString());
      localBufferedWriter.newLine();
      localBufferedWriter.close();
      synchronized (this.warpLock)
      {
        this.warps.add(paramWarp);
      }
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while writing new warp to ").append(str).toString(), localException);
    }
  }

  public void changeWarp(Warp paramWarp)
  {
    Object localObject2;
    Object localObject3;
    synchronized (this.warpLock)
    {
      localObject1 = null;
      localObject2 = this.warps.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Warp)((Iterator)localObject2).next();
        if (((Warp)localObject3).Name.equalsIgnoreCase(paramWarp.Name))
          localObject1 = localObject3;
      }
      if (localObject1 != null)
        this.warps.remove(localObject1);
      this.warps.add(paramWarp);
    }
    ??? = null;
    Object localObject1 = etc.getInstance().getWarpLocation();
    try
    {
      localObject2 = new BufferedReader(new FileReader(new File((String)localObject1)));
      localObject3 = new StringBuilder();
      String str = "";
      while ((str = ((BufferedReader)localObject2).readLine()) != null)
      {
        if (!str.split(":")[0].equalsIgnoreCase(paramWarp.Name))
        {
          ((StringBuilder)localObject3).append(str).append("\r\n");
          continue;
        }
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(paramWarp.Name);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.x);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.y);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.z);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.rotX);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Location.rotY);
        localStringBuilder.append(":");
        localStringBuilder.append(paramWarp.Group);
        ((StringBuilder)localObject3).append(localStringBuilder.toString()).append("\r\n");
      }
      ((BufferedReader)localObject2).close();
      ??? = new FileWriter((String)localObject1);
      ((FileWriter)???).write(((StringBuilder)localObject3).toString());
      ((FileWriter)???).close();
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while editing warp in ").append((String)localObject1).toString(), localException);
    }
    finally
    {
      try
      {
        if (??? != null)
          ((FileWriter)???).close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void removeWarp(Warp paramWarp)
  {
    FileWriter localFileWriter = null;
    String str1 = etc.getInstance().getWarpLocation();
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(new File(str1)));
      StringBuilder localStringBuilder = new StringBuilder();
      String str2 = "";
      while ((str2 = localBufferedReader.readLine()) != null)
      {
        if (str2.split(":")[0].equalsIgnoreCase(paramWarp.Name))
          continue;
        localStringBuilder.append(str2).append("\r\n");
      }
      localBufferedReader.close();
      localFileWriter = new FileWriter(str1);
      localFileWriter.write(localStringBuilder.toString());
      localFileWriter.close();
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while delete warp from ").append(str1).toString(), localException);
    }
    finally
    {
      try
      {
        if (localFileWriter != null)
          localFileWriter.close();
      }
      catch (IOException localIOException3)
      {
      }
    }
    synchronized (this.warpLock)
    {
      this.warps.remove(paramWarp);
    }
  }

  public void addToWhitelist(String paramString)
  {
    if (isUserOnWhitelist(paramString))
      return;
    BufferedWriter localBufferedWriter = null;
    String str = etc.getInstance().getWhitelistLocation();
    try
    {
      localBufferedWriter = new BufferedWriter(new FileWriter(str, true));
      localBufferedWriter.newLine();
      localBufferedWriter.append(paramString);
      synchronized (this.whiteListLock)
      {
        this.whiteList.add(paramString);
      }
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while writing new user to ").append(str).toString(), localException);
    }
    finally
    {
      try
      {
        if (localBufferedWriter != null)
          localBufferedWriter.close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void removeFromWhitelist(String paramString)
  {
    if (!isUserOnWhitelist(paramString))
      return;
    synchronized (this.whiteListLock)
    {
      this.whiteList.remove(paramString);
    }
    ??? = null;
    String str1 = etc.getInstance().getWhitelistLocation();
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(new File(str1)));
      String str2 = "";
      StringBuilder localStringBuilder = new StringBuilder();
      while ((str2 = localBufferedReader.readLine()) != null)
      {
        if (str2.equalsIgnoreCase(paramString.toLowerCase()))
          continue;
        localStringBuilder.append(str2).append("\r\n");
      }
      localBufferedReader.close();
      ??? = new FileWriter(str1);
      ((FileWriter)???).write(localStringBuilder.toString());
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while removing player '").append(paramString).append("' from ").append(str1).toString(), localException);
    }
    finally
    {
      try
      {
        if (??? != null)
          ((FileWriter)???).close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void addToReserveList(String paramString)
  {
    if (isUserOnReserveList(paramString))
      return;
    BufferedWriter localBufferedWriter = null;
    String str = etc.getInstance().getReservelistLocation();
    try
    {
      localBufferedWriter = new BufferedWriter(new FileWriter(str, true));
      localBufferedWriter.newLine();
      localBufferedWriter.append(paramString);
      synchronized (this.whiteListLock)
      {
        this.reserveList.add(paramString);
      }
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while writing new user to ").append(str).toString(), localException);
    }
    finally
    {
      try
      {
        if (localBufferedWriter != null)
          localBufferedWriter.close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void removeFromReserveList(String paramString)
  {
    if (!isUserOnReserveList(paramString))
      return;
    synchronized (this.reserveListLock)
    {
      this.reserveList.remove(paramString);
    }
    ??? = null;
    String str1 = etc.getInstance().getReservelistLocation();
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(new File(str1)));
      String str2 = "";
      StringBuilder localStringBuilder = new StringBuilder();
      while ((str2 = localBufferedReader.readLine()) != null)
      {
        if (str2.equalsIgnoreCase(paramString.toLowerCase()))
          continue;
        localStringBuilder.append(str2).append("\r\n");
      }
      localBufferedReader.close();
      ??? = new FileWriter(str1);
      ((FileWriter)???).write(localStringBuilder.toString());
    }
    catch (Exception localIOException2)
    {
      log.log(Level.SEVERE, new StringBuilder().append("Exception while removing player '").append(paramString).append("' from ").append(str1).toString(), localException);
    }
    finally
    {
      try
      {
        if (??? != null)
          ((FileWriter)???).close();
      }
      catch (IOException localIOException3)
      {
      }
    }
  }

  public void modifyBan(Ban paramBan)
  {
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     FlatFileSource
 * JD-Core Version:    0.6.0
 */