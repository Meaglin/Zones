public class Sign
  implements ComplexBlock
{
  private ig sign;

  public Sign(ig paramig)
  {
    this.sign = paramig;
  }

  public void setText(int paramInt, String paramString)
  {
    if ((paramInt >= 0) && (this.sign.e.length > paramInt))
      this.sign.e[paramInt] = paramString;
  }

  public String getText(int paramInt)
  {
    if ((paramInt >= 0) && (this.sign.e.length > paramInt))
      return this.sign.e[paramInt];
    return "";
  }

  public int getX()
  {
    return this.sign.b;
  }

  public int getY()
  {
    return this.sign.c;
  }

  public int getZ()
  {
    return this.sign.d;
  }

  public void update()
  {
    this.sign.c();
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Sign
 * JD-Core Version:    0.6.0
 */