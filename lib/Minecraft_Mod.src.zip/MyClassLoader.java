import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collection;
import java.util.jar.JarFile;

public class MyClassLoader extends URLClassLoader
{
  public MyClassLoader(URL[] paramArrayOfURL, ClassLoader paramClassLoader)
  {
    super(paramArrayOfURL, paramClassLoader);
  }

  public void close()
  {
    try
    {
      URLClassLoader localURLClassLoader = URLClassLoader.class;
      Field localField1 = localURLClassLoader.getDeclaredField("ucp");
      localField1.setAccessible(true);
      Object localObject1 = localField1.get(this);
      Field localField2 = localObject1.getClass().getDeclaredField("loaders");
      localField2.setAccessible(true);
      Object localObject2 = localField2.get(localObject1);
      for (Object localObject3 : ((Collection)localObject2).toArray())
        try
        {
          Field localField3 = localObject3.getClass().getDeclaredField("jar");
          localField3.setAccessible(true);
          Object localObject4 = localField3.get(localObject3);
          ((JarFile)localObject4).close();
        }
        catch (Throwable localThrowable2)
        {
        }
    }
    catch (Throwable localThrowable1)
    {
    }
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     MyClassLoader
 * JD-Core Version:    0.6.0
 */