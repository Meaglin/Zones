public class HitBlox
{
  private Location player_loc;
  private double rot_x;
  private double rot_y;
  private double view_height;
  private double length;
  private double h_length;
  private double step;
  private int range;
  private double x_offset;
  private double y_offset;
  private double z_offset;
  private int last_x;
  private int last_y;
  private int last_z;
  private int target_x;
  private int target_y;
  private int target_z;
  private int target_type;

  public HitBlox(Player paramPlayer)
  {
    init(paramPlayer.getLocation(), 200, 0.2D, 1.65D);
  }

  public HitBlox(Location paramLocation)
  {
    init(paramLocation, 200, 0.2D, 0.0D);
  }

  public HitBlox(Player paramPlayer, int paramInt, double paramDouble)
  {
    init(paramPlayer.getLocation(), paramInt, paramDouble, 1.65D);
  }

  public HitBlox(Location paramLocation, int paramInt, double paramDouble)
  {
    init(paramLocation, paramInt, paramDouble, 0.0D);
  }

  public void init(Location paramLocation, int paramInt, double paramDouble1, double paramDouble2)
  {
    this.player_loc = paramLocation;
    this.view_height = paramDouble2;
    this.range = paramInt;
    this.step = paramDouble1;
    this.length = 0.0D;
    this.rot_x = ((this.player_loc.rotX + 90.0F) % 360.0F);
    this.rot_y = (this.player_loc.rotY * -1.0F);
    this.target_x = (int)Math.floor(this.player_loc.x);
    this.target_y = (int)Math.floor(this.player_loc.y + this.view_height);
    this.target_z = (int)Math.floor(this.player_loc.z);
    this.last_x = this.target_x;
    this.last_y = this.target_y;
    this.last_z = this.target_z;
  }

  public Block getTargetBlock()
  {
    while ((getNextBlock() != null) && (getCurBlock().getType() == 0));
    return getCurBlock();
  }

  public void setTargetBlock(int paramInt)
  {
    while ((getNextBlock() != null) && (getCurBlock().getType() == 0));
    if (getCurBlock() != null)
      etc.getServer().setBlockAt(paramInt, this.target_x, this.target_y, this.target_z);
  }

  public Block getFaceBlock()
  {
    while ((getNextBlock() != null) && (getCurBlock().getType() == 0));
    if (getCurBlock() != null)
      return null;
    return getLastBlock();
  }

  public void setFaceBlock(int paramInt)
  {
    while ((getNextBlock() != null) && (getCurBlock().getType() == 0));
    if (getCurBlock() != null)
      etc.getServer().setBlockAt(paramInt, this.last_x, this.last_y, this.last_z);
  }

  public Block getNextBlock()
  {
    this.last_x = this.target_x;
    this.last_y = this.target_y;
    this.last_z = this.target_z;
    do
    {
      this.length += this.step;
      this.h_length = (this.length * Math.cos(Math.toRadians(this.rot_y)));
      this.y_offset = (this.length * Math.sin(Math.toRadians(this.rot_y)));
      this.x_offset = (this.h_length * Math.cos(Math.toRadians(this.rot_x)));
      this.z_offset = (this.h_length * Math.sin(Math.toRadians(this.rot_x)));
      this.target_x = (int)Math.floor(this.x_offset + this.player_loc.x);
      this.target_y = (int)Math.floor(this.y_offset + this.player_loc.y + this.view_height);
      this.target_z = (int)Math.floor(this.z_offset + this.player_loc.z);
    }
    while ((this.length <= this.range) && (this.target_x == this.last_x) && (this.target_y == this.last_y) && (this.target_z == this.last_z));
    if (this.length > this.range)
      return null;
    return etc.getServer().getBlockAt(this.target_x, this.target_y, this.target_z);
  }

  public Block getCurBlock()
  {
    if (this.length > this.range)
      return null;
    return etc.getServer().getBlockAt(this.target_x, this.target_y, this.target_z);
  }

  public void setCurBlock(int paramInt)
  {
    if (getCurBlock() != null)
      etc.getServer().setBlockAt(paramInt, this.target_x, this.target_y, this.target_z);
  }

  public Block getLastBlock()
  {
    return etc.getServer().getBlockAt(this.last_x, this.last_y, this.last_z);
  }

  public void setLastBlock(int paramInt)
  {
    if (getLastBlock() != null)
      etc.getServer().setBlockAt(paramInt, this.last_x, this.last_y, this.last_z);
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     HitBlox
 * JD-Core Version:    0.6.0
 */