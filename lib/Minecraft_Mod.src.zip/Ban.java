public class Ban
{
  private String name = "N/A";
  private String ip = "";
  private String reason = "N/A";
  private int id = -1;
  private int timestamp = -1;

  public String getIp()
  {
    return this.ip;
  }

  public void setIp(String paramString)
  {
    this.ip = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getReason()
  {
    return this.reason;
  }

  public void setReason(String paramString)
  {
    this.reason = paramString;
  }

  public int getTimestamp()
  {
    return this.timestamp;
  }

  public void setTimestamp(int paramInt)
  {
    this.timestamp = paramInt;
  }

  public int getId()
  {
    return this.id;
  }

  public void setId(int paramInt)
  {
    this.id = paramInt;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Ban
 * JD-Core Version:    0.6.0
 */