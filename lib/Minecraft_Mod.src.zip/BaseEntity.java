public class BaseEntity
{
  is entity;

  public void teleportTo(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2)
  {
    this.entity.b(paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2);
  }

  public void teleportTo(BaseEntity paramBaseEntity)
  {
    teleportTo(paramBaseEntity.getX(), paramBaseEntity.getY(), paramBaseEntity.getZ(), paramBaseEntity.getRotation(), paramBaseEntity.getPitch());
  }

  public void teleportTo(Location paramLocation)
  {
    teleportTo(paramLocation.x, paramLocation.y, paramLocation.z, paramLocation.rotX, paramLocation.rotY);
  }

  public double getX()
  {
    return this.entity.l;
  }

  public void setX(double paramDouble)
  {
    teleportTo(paramDouble, getY(), getZ(), getRotation(), getPitch());
  }

  public double getY()
  {
    return this.entity.m;
  }

  public void setY(double paramDouble)
  {
    teleportTo(getX(), paramDouble, getZ(), getRotation(), getPitch());
  }

  public double getZ()
  {
    return this.entity.n;
  }

  public void setZ(double paramDouble)
  {
    teleportTo(getX(), getY(), paramDouble, getRotation(), getPitch());
  }

  public float getPitch()
  {
    return this.entity.s;
  }

  public void setPitch(float paramFloat)
  {
    teleportTo(getX(), getY(), getZ(), getRotation(), paramFloat);
  }

  public float getRotation()
  {
    return this.entity.r;
  }

  public void setRotation(float paramFloat)
  {
    teleportTo(getX(), getY(), getZ(), paramFloat, getPitch());
  }

  public int getHealth()
  {
    return this.entity.aM;
  }

  public void setHealth(int paramInt)
  {
    this.entity.aM = paramInt;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     BaseEntity
 * JD-Core Version:    0.6.0
 */