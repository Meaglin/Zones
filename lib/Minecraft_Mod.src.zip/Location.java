public class Location
{
  public double x;
  public double z;
  public double y;
  public float rotX;
  public float rotY;

  public Location()
  {
  }

  public Location(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
  }

  public Location(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2)
  {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
    this.rotX = paramFloat1;
    this.rotY = paramFloat2;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Location
 * JD-Core Version:    0.6.0
 */