public class Chest extends ItemArray
  implements ComplexBlock
{
  private hb chest;

  public Chest(hb paramhb)
  {
    this.chest = paramhb;
  }

  public int getX()
  {
    return this.chest.b;
  }

  public int getY()
  {
    return this.chest.c;
  }

  public int getZ()
  {
    return this.chest.d;
  }

  public void update()
  {
    this.chest.c();
  }

  public gp[] getArray()
  {
    return this.chest.getContents();
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Chest
 * JD-Core Version:    0.6.0
 */