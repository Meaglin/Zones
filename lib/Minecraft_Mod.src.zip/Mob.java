import net.minecraft.server.MinecraftServer;

public class Mob extends BaseEntity
{
  private gh mob = null;

  public Mob(String paramString)
  {
    this.mob = ((gh)gr.a(paramString, etc.getMCServer().e));
    this.entity = this.mob;
  }

  public Mob(String paramString, Location paramLocation)
  {
    this.mob = ((gh)gr.a(paramString, etc.getMCServer().e));
    this.entity = this.mob;
    teleportTo(paramLocation);
  }

  public Mob(gh paramgh)
  {
    this.mob = paramgh;
    this.entity = this.mob;
  }

  public void spawn()
  {
    spawn(null);
  }

  public void spawn(Mob paramMob)
  {
    ee localee = etc.getMCServer().e;
    this.mob.c(getX() + 0.5D, getY(), getZ() + 0.5D, getRotation(), 0.0F);
    localee.a(this.mob);
    if (paramMob != null)
    {
      gh localgh = paramMob.getMob();
      localgh.c(getX(), getY(), getZ(), getRotation(), 0.0F);
      localee.a(localgh);
      localgh.e(this.mob);
    }
  }

  public String getName()
  {
    return gr.b(this.mob);
  }

  public void dropLoot()
  {
    this.mob.f(null);
  }

  public void setHealth(int paramInt)
  {
    super.setHealth(paramInt);
    if (paramInt <= 0)
      dropLoot();
  }

  public gh getMob()
  {
    return this.mob;
  }

  public static boolean isValid(String paramString)
  {
    if (paramString == null)
      return false;
    return gr.a(paramString, etc.getMCServer().e) instanceof is;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Mob
 * JD-Core Version:    0.6.0
 */