import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;

public class etc
{
  private static final Logger log = Logger.getLogger("Minecraft");
  private static volatile etc instance;
  private static MinecraftServer server;
  private String usersLoc = "users.txt";
  private String kitsLoc = "kits.txt";
  private String homeLoc = "homes.txt";
  private String warpLoc = "warps.txt";
  private String itemLoc = "items.txt";
  private String groupLoc = "groups.txt";
  private String whitelistLoc = "whitelist.txt";
  private String reservelistLoc = "reservelist.txt";
  private String whitelistMessage = "Not on whitelist.";
  private String[] allowedItems = null;
  private String[] disallowedItems = null;
  private String[] itemSpawnBlacklist = null;
  private String[] motd = null;
  private boolean saveHomes = true;
  private boolean firstLoad = true;
  private boolean whitelistEnabled = false;
  private int playerLimit = 20;
  private int spawnProtectionSize = 16;
  private LinkedHashMap<String, String> commands = new LinkedHashMap();
  private String dataSourceType;
  private DataSource dataSource;
  private PropertiesFile properties;
  private PluginLoader loader;
  private boolean logging = false;
  private boolean showUnknownCommand = true;
  private int version = 1;

  private etc()
  {
    this.commands.put("/help", "[Page] - Shows a list of commands. 7 per page.");
    this.commands.put("/playerlist", "- Shows a list of players");
    this.commands.put("/reload", "- Reloads config");
    this.commands.put("/listbans", "<IP or bans> - Gives a list of bans");
    this.commands.put("/banip", "[Player] <Reason> - Bans the player's IP");
    this.commands.put("/unbanip", "[IP] - Unbans the IP");
    this.commands.put("/ban", "[Player] <Reason> - Bans the player");
    this.commands.put("/unban", "[Player] - Unbans the player");
    this.commands.put("/mute", "[Player] - Toggles mute on player.");
    this.commands.put("/tp", "[Player] - Teleports to player. Credits to Zet from SA");
    this.commands.put("/tphere", "[Player] - Teleports the player to you");
    this.commands.put("/kick", "[Player] <Reason> - Kicks player");
    this.commands.put("/item", "[ID] [Amount] <Player> - Gives items");
    this.commands.put("/kit", "[Kit] - Gives a kit. To get a list of kits type /kit");
    this.commands.put("/listwarps", "- Gives a list of available warps");
    this.commands.put("/home", "- Teleports you home");
    this.commands.put("/sethome", "- Sets your home");
    this.commands.put("/setspawn", "- Sets the spawn point to your position.");
    this.commands.put("/me", "[Message] - * hey0 says hi!");
    this.commands.put("/msg", "[Player] [Message] - Sends a message to player");
    this.commands.put("/spawn", "- Teleports you to spawn");
    this.commands.put("/warp", "[Warp] - Warps to the specified warp.");
    this.commands.put("/setwarp", "[Warp] - Sets the warp to your current position.");
    this.commands.put("/removewarp", "[Warp] - Removes the specified warp.");
    this.commands.put("/getpos", "- Displays your current position.");
    this.commands.put("/compass", "- Gives you a compass reading.");
    this.commands.put("/time", "[Time|day|night] - Changes time");
    this.commands.put("/lighter", "- Gives you a lighter for lighting furnaces");
    this.commands.put("/motd", "- Displays the MOTD");
    this.commands.put("/modify", "[player] [key] [value] - Type /modify for more info");
    this.commands.put("/whitelist", "[operation (add or remove)] [player]");
    this.commands.put("/reservelist", "[operation (add or remove)] [player]");
    this.commands.put("/enableplugin", "[plugin] - Enables plugin");
    this.commands.put("/disableplugin", "[plugin] - Disables plugin");
    this.commands.put("/listplugins", "- Lists all plugins");
    this.commands.put("/reloadplugin", "[plugin] - Reloads plugin");
    this.commands.put("/clearinventory", "- Clears your inventory");
    load();
  }

  public final void load()
  {
    if (this.properties == null)
      this.properties = new PropertiesFile("server.properties");
    else
      this.properties.load();
    try
    {
      this.dataSourceType = this.properties.getString("data-source", "flatfile");
      this.allowedItems = this.properties.getString("alloweditems", "").split(",");
      this.disallowedItems = this.properties.getString("disalloweditems", "").split(",");
      this.itemSpawnBlacklist = this.properties.getString("itemspawnblacklist", "").split(",");
      this.motd = this.properties.getString("motd", "Type /help for a list of commands.").split("@");
      this.playerLimit = this.properties.getInt("max-players", 20);
      this.saveHomes = this.properties.getBoolean("save-homes", true);
      this.whitelistEnabled = this.properties.getBoolean("whitelist", false);
      this.whitelistMessage = this.properties.getString("whitelist-message", "Not on whitelist.");
      if (this.dataSourceType.equalsIgnoreCase("flatfile"))
      {
        this.usersLoc = this.properties.getString("admintxtlocation", "users.txt");
        this.kitsLoc = this.properties.getString("kitstxtlocation", "kits.txt");
        this.homeLoc = this.properties.getString("homelocation", "homes.txt");
        this.warpLoc = this.properties.getString("warplocation", "warps.txt");
        this.itemLoc = this.properties.getString("itemstxtlocation", "items.txt");
        this.groupLoc = this.properties.getString("group-txt-location", "groups.txt");
        this.whitelistLoc = this.properties.getString("whitelist-txt-location", "whitelist.txt");
        this.reservelistLoc = this.properties.getString("reservelist-txt-location", "reservelist.txt");
      }
      this.spawnProtectionSize = this.properties.getInt("spawn-protection-size", 16);
      this.logging = this.properties.getBoolean("logging", false);
      this.showUnknownCommand = this.properties.getBoolean("show-unknown-command", true);
      URL localURL = getClass().getResource("/version.txt");
      if (localURL != null)
      {
        InputStreamReader localInputStreamReader = new InputStreamReader(localURL.openStream());
        BufferedReader localBufferedReader = new BufferedReader(localInputStreamReader);
        this.version = Integer.parseInt(localBufferedReader.readLine());
      }
    }
    catch (Exception localException)
    {
      log.log(Level.SEVERE, "Exception while reading from server.properties", localException);
      this.disallowedItems = new String[] { "" };
      this.allowedItems = new String[] { "" };
      this.itemSpawnBlacklist = new String[] { "" };
      this.motd = new String[] { "Type /help for a list of commands." };
    }
  }

  public void loadData()
  {
    if ((this.dataSourceType.equalsIgnoreCase("flatfile")) && (this.dataSource == null))
      this.dataSource = new FlatFileSource();
    else if ((this.dataSourceType.equalsIgnoreCase("mysql")) && (this.dataSource == null))
      this.dataSource = new MySQLSource();
    this.dataSource.initialize();
  }

  public static etc getInstance()
  {
    if (instance == null)
      instance = new etc();
    return instance;
  }

  public static void setServer(MinecraftServer paramMinecraftServer)
  {
    server = paramMinecraftServer;
  }

  public static MinecraftServer getMCServer()
  {
    return server;
  }

  public static DataSource getDataSource()
  {
    return getInstance().getSource();
  }

  public static Server getServer()
  {
    return getLoader().getServer();
  }

  public static PluginLoader getLoader()
  {
    if (instance.loader == null)
    {
      instance.loader = new PluginLoader(server);
      instance.loader.loadPlugins();
    }
    return instance.loader;
  }

  public Group getDefaultGroup()
  {
    Group localGroup = this.dataSource.getDefaultGroup();
    if (localGroup == null)
      log.log(Level.SEVERE, "No default group! Expect lots of errors!");
    return localGroup;
  }

  public void changeHome(Warp paramWarp)
  {
    if (this.dataSource.getHome(paramWarp.Name) == null)
      this.dataSource.addHome(paramWarp);
    else
      this.dataSource.changeHome(paramWarp);
  }

  public void setWarp(Warp paramWarp)
  {
    if (this.dataSource.getWarp(paramWarp.Name) == null)
      this.dataSource.addWarp(paramWarp);
    else
      this.dataSource.changeWarp(paramWarp);
  }

  public boolean isOnItemBlacklist(int paramInt)
  {
    for (String str : this.itemSpawnBlacklist)
      if (Integer.toString(paramInt).equalsIgnoreCase(str))
        return true;
    return false;
  }

  public DataSource getSource()
  {
    return this.dataSource;
  }

  public boolean isLogging()
  {
    return this.logging;
  }

  public void addCommand(String paramString1, String paramString2)
  {
    this.commands.put(paramString1, paramString2);
  }

  public void removeCommand(String paramString)
  {
    this.commands.remove(paramString);
  }

  public boolean toggleWhitelist()
  {
    this.whitelistEnabled = (!this.whitelistEnabled);
    return this.whitelistEnabled;
  }

  public boolean parseConsoleCommand(String paramString, MinecraftServer paramMinecraftServer)
  {
    if (getMCServer() == null)
      setServer(paramMinecraftServer);
    String[] arrayOfString = paramString.split(" ");
    if (((Boolean)getLoader().callHook(PluginLoader.Hook.SERVERCOMMAND, new Object[] { arrayOfString })).booleanValue())
      return true;
    if (arrayOfString.length == 0)
      return false;
    int i = 1;
    if ((arrayOfString[0].equalsIgnoreCase("help")) || (arrayOfString[0].equalsIgnoreCase("mod-help")))
    {
      if (arrayOfString[0].equalsIgnoreCase("help"))
        i = 0;
      log.info("Server mod help:");
      log.info("help          Displays this mod's and server's help");
      log.info("mod-help      Displays this mod's help");
      log.info("version       Displays the server version");
      log.info("reload        Reloads the config");
      log.info("modify        Type modify for more info");
      log.info("whitelist     Type whitelist for more info");
      log.info("reservelist   Type reservelist for more info");
      log.info("listplugins   Lists all plugins");
      log.info("enableplugin  Enables a plugin");
      log.info("disableplugin Disables a plugin");
      log.info("reloadplugin  Reloads a plugin");
    }
    else
    {
      Object localObject1;
      Object localObject2;
      if (arrayOfString[0].equalsIgnoreCase("reload"))
      {
        load();
        loadData();
        localObject1 = getServer().getPlayerList().iterator();
        while (((Iterator)localObject1).hasNext())
        {
          localObject2 = (Player)((Iterator)localObject1).next();
          ((Player)localObject2).getUser().reloadPlayer();
        }
        log.info("Reloaded mod");
      }
      else if (arrayOfString[0].equalsIgnoreCase("modify"))
      {
        if (arrayOfString.length < 4)
        {
          log.info("Usage is: /modify [player] [key] [value]");
          log.info("Keys:");
          log.info("prefix: only the letter the color represents");
          log.info("commands: list seperated by comma");
          log.info("groups: list seperated by comma");
          log.info("ignoresrestrictions: true or false");
          log.info("admin: true or false");
          log.info("modworld: true or false");
          return true;
        }
        localObject1 = getServer().matchPlayer(arrayOfString[1]);
        if (localObject1 == null)
        {
          log.info("Player does not exist.");
          return true;
        }
        localObject2 = arrayOfString[2];
        String str = arrayOfString[3];
        int j = 0;
        if (!getDataSource().doesPlayerExist(((Player)localObject1).getName()))
        {
          if ((!((String)localObject2).equalsIgnoreCase("groups")) && (!((String)localObject2).equalsIgnoreCase("g")))
          {
            log.info("When adding a new user, set their group(s) first.");
            return true;
          }
          log.info("Adding new user.");
          j = 1;
        }
        if ((((String)localObject2).equalsIgnoreCase("prefix")) || (((String)localObject2).equalsIgnoreCase("p")))
          ((Player)localObject1).setPrefix(str);
        else if ((((String)localObject2).equalsIgnoreCase("commands")) || (((String)localObject2).equalsIgnoreCase("c")))
          ((Player)localObject1).setCommands(str.split(","));
        else if ((((String)localObject2).equalsIgnoreCase("groups")) || (((String)localObject2).equalsIgnoreCase("g")))
          ((Player)localObject1).setGroups(str.split(","));
        else if ((((String)localObject2).equalsIgnoreCase("ignoresrestrictions")) || (((String)localObject2).equalsIgnoreCase("ir")))
          ((Player)localObject1).setIgnoreRestrictions((str.equalsIgnoreCase("true")) || (str.equals("1")));
        else if ((((String)localObject2).equalsIgnoreCase("admin")) || (((String)localObject2).equalsIgnoreCase("a")))
          ((Player)localObject1).setAdmin((str.equalsIgnoreCase("true")) || (str.equals("1")));
        else if ((((String)localObject2).equalsIgnoreCase("modworld")) || (((String)localObject2).equalsIgnoreCase("mw")))
          ((Player)localObject1).setCanModifyWorld((str.equalsIgnoreCase("true")) || (str.equals("1")));
        if (j != 0)
          getDataSource().addPlayer((Player)localObject1);
        else
          getDataSource().modifyPlayer((Player)localObject1);
        log.info(new StringBuilder().append("Modifed user ").append(arrayOfString[1]).append(". ").append((String)localObject2).append(" => ").append(str).toString());
      }
      else if (arrayOfString[0].equalsIgnoreCase("whitelist"))
      {
        if (arrayOfString.length < 2)
        {
          log.info("whitelist [operation (toggle, add or remove)] [player]");
          return true;
        }
        if (arrayOfString[1].equalsIgnoreCase("toggle"))
          log.info(toggleWhitelist() ? "Whitelist enabled" : "Whitelist disabled");
        else if (arrayOfString.length == 3)
        {
          if (arrayOfString[1].equalsIgnoreCase("add"))
          {
            this.dataSource.addToWhitelist(arrayOfString[2]);
            log.info(new StringBuilder().append(arrayOfString[2]).append(" added to whitelist").toString());
          }
          else if (arrayOfString[1].equalsIgnoreCase("remove"))
          {
            this.dataSource.removeFromWhitelist(arrayOfString[2]);
            log.info(new StringBuilder().append(arrayOfString[2]).append(" removed from whitelist").toString());
          }
          else
          {
            log.info("Invalid operation.");
          }
        }
        else
          log.info("Invalid operation.");
      }
      else if (arrayOfString[0].equalsIgnoreCase("reservelist"))
      {
        if (arrayOfString.length != 3)
        {
          log.info("reservelist [operation (add or remove)] [player]");
          return true;
        }
        if (arrayOfString[1].equalsIgnoreCase("add"))
        {
          this.dataSource.addToReserveList(arrayOfString[2]);
          log.info(new StringBuilder().append(arrayOfString[2]).append(" added to reservelist").toString());
        }
        else if (arrayOfString[1].equalsIgnoreCase("remove"))
        {
          this.dataSource.removeFromReserveList(arrayOfString[2]);
          log.info(new StringBuilder().append(arrayOfString[2]).append(" removed from reservelist").toString());
        }
        else
        {
          log.info("Invalid operation.");
        }
      }
      else if (arrayOfString[0].equalsIgnoreCase("listplugins"))
      {
        log.info(new StringBuilder().append("Plugins: ").append(getLoader().getPluginList()).toString());
      }
      else if (arrayOfString[0].equalsIgnoreCase("reloadplugin"))
      {
        if (arrayOfString.length < 2)
        {
          log.info("Correct usage is: reloadplugin [plugin]");
          return true;
        }
        getLoader().reloadPlugin(arrayOfString[1]);
        log.info("Plugin reloaded.");
      }
      else if (arrayOfString[0].equalsIgnoreCase("enableplugin"))
      {
        if (arrayOfString.length < 2)
        {
          log.info("Correct usage is: enableplugin [plugin]");
          return true;
        }
        getLoader().enablePlugin(arrayOfString[1]);
        log.info("Plugin enabled.");
      }
      else if (arrayOfString[0].equalsIgnoreCase("disableplugin"))
      {
        if (arrayOfString.length < 2)
        {
          log.info("Correct usage is: enableplugin [plugin]");
          return true;
        }
        getLoader().disablePlugin(arrayOfString[1]);
        log.info("Plugin disabled.");
      }
      else if (arrayOfString[0].equalsIgnoreCase("version"))
      {
        log.info(new StringBuilder().append("Hey0 Server Mod Build ").append(this.version).toString());
      }
      else
      {
        i = 0;
      }
    }
    return i;
  }

  public static String getCompassPointForDirection(double paramDouble)
  {
    if ((0.0D <= paramDouble) && (paramDouble < 22.5D))
      return "N";
    if ((22.5D <= paramDouble) && (paramDouble < 67.5D))
      return "NE";
    if ((67.5D <= paramDouble) && (paramDouble < 112.5D))
      return "E";
    if ((112.5D <= paramDouble) && (paramDouble < 157.5D))
      return "SE";
    if ((157.5D <= paramDouble) && (paramDouble < 202.5D))
      return "S";
    if ((202.5D <= paramDouble) && (paramDouble < 247.5D))
      return "SW";
    if ((247.5D <= paramDouble) && (paramDouble < 292.5D))
      return "W";
    if ((292.5D <= paramDouble) && (paramDouble < 337.5D))
      return "NW";
    if ((337.5D <= paramDouble) && (paramDouble < 360.0D))
      return "N";
    return "ERR";
  }

  public static String combineSplit(int paramInt, String[] paramArrayOfString, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = paramInt; i < paramArrayOfString.length; i++)
    {
      localStringBuilder.append(paramArrayOfString[i]);
      localStringBuilder.append(paramString);
    }
    localStringBuilder.deleteCharAt(localStringBuilder.length() - paramString.length());
    return localStringBuilder.toString();
  }

  public String[] getAllowedItems()
  {
    return this.allowedItems;
  }

  public LinkedHashMap<String, String> getCommands()
  {
    return this.commands;
  }

  public String[] getDisallowedItems()
  {
    return this.disallowedItems;
  }

  public String getGroupLocation()
  {
    return this.groupLoc;
  }

  public String getHomeLocation()
  {
    return this.homeLoc;
  }

  public String getItemLocation()
  {
    return this.itemLoc;
  }

  public String[] getItemSpawnBlacklist()
  {
    return this.itemSpawnBlacklist;
  }

  public String getKitsLocation()
  {
    return this.kitsLoc;
  }

  public String[] getMotd()
  {
    return this.motd;
  }

  public int getPlayerLimit()
  {
    return this.playerLimit;
  }

  public String getReservelistLocation()
  {
    return this.reservelistLoc;
  }

  public boolean canSaveHomes()
  {
    return this.saveHomes;
  }

  public int getSpawnProtectionSize()
  {
    return this.spawnProtectionSize;
  }

  public String getUsersLocation()
  {
    return this.usersLoc;
  }

  public String getWarpLocation()
  {
    return this.warpLoc;
  }

  public boolean isWhitelistEnabled()
  {
    return this.whitelistEnabled;
  }

  public String getWhitelistLocation()
  {
    return this.whitelistLoc;
  }

  public String getWhitelistMessage()
  {
    return this.whitelistMessage;
  }

  public void setAllowedItems(String[] paramArrayOfString)
  {
    this.allowedItems = paramArrayOfString;
  }

  public void setDisallowedItems(String[] paramArrayOfString)
  {
    this.disallowedItems = paramArrayOfString;
  }

  public void setGroupLocation(String paramString)
  {
    this.groupLoc = paramString;
  }

  public void setHomeLocation(String paramString)
  {
    this.homeLoc = paramString;
  }

  public void setItemLocation(String paramString)
  {
    this.itemLoc = paramString;
  }

  public void setItemSpawnBlacklist(String[] paramArrayOfString)
  {
    this.itemSpawnBlacklist = paramArrayOfString;
  }

  public void setKitsLocation(String paramString)
  {
    this.kitsLoc = paramString;
  }

  public void setLogging(boolean paramBoolean)
  {
    this.logging = paramBoolean;
  }

  public void setMotd(String[] paramArrayOfString)
  {
    this.motd = paramArrayOfString;
  }

  public void setPlayerLimit(int paramInt)
  {
    this.playerLimit = paramInt;
  }

  public void setReservelistLocation(String paramString)
  {
    this.reservelistLoc = paramString;
  }

  public void setSaveHomes(boolean paramBoolean)
  {
    this.saveHomes = paramBoolean;
  }

  public void setSpawnProtectionSize(int paramInt)
  {
    this.spawnProtectionSize = paramInt;
  }

  public void setUsersLocation(String paramString)
  {
    this.usersLoc = paramString;
  }

  public void setWarpLocation(String paramString)
  {
    this.warpLoc = paramString;
  }

  public void setWhitelistEnabled(boolean paramBoolean)
  {
    this.whitelistEnabled = paramBoolean;
  }

  public void setWhitelistLocation(String paramString)
  {
    this.whitelistLoc = paramString;
  }

  public void setWhitelistMessage(String paramString)
  {
    this.whitelistMessage = paramString;
  }

  public boolean showUnknownCommand()
  {
    return this.showUnknownCommand;
  }

  public void setShowUnknownCommand(boolean paramBoolean)
  {
    this.showUnknownCommand = paramBoolean;
  }

  public int getVersion()
  {
    return this.version;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     etc
 * JD-Core Version:    0.6.0
 */