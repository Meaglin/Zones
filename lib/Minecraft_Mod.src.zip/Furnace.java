public class Furnace extends ItemArray
  implements ComplexBlock
{
  private df furnace;

  public Furnace(df paramdf)
  {
    this.furnace = paramdf;
  }

  public int getX()
  {
    return this.furnace.b;
  }

  public int getY()
  {
    return this.furnace.c;
  }

  public int getZ()
  {
    return this.furnace.d;
  }

  public void update()
  {
    this.furnace.c();
  }

  public gp[] getArray()
  {
    return this.furnace.getContents();
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Furnace
 * JD-Core Version:    0.6.0
 */