import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;

public class ft
{
  public static Logger a = Logger.getLogger("Minecraft");
  public List b = new ArrayList();
  private MinecraftServer c;
  private hg d;
  private int e;
  private ArrayList f = new ArrayList();
  private ArrayList g = new ArrayList();
  private ArrayList h = new ArrayList();
  private File i;
  private File j;
  private File k;
  private cl l;

  public ft(MinecraftServer paramMinecraftServer)
  {
    etc.setServer(paramMinecraftServer);
    etc.getInstance().loadData();
    a.info(new StringBuilder().append("Hey0 Server Mod Build ").append(etc.getInstance().getVersion()).toString());
    this.c = paramMinecraftServer;
    this.i = paramMinecraftServer.a("banned-players.txt");
    this.j = paramMinecraftServer.a("banned-ips.txt");
    this.k = paramMinecraftServer.a("ops.txt");
    this.d = new hg(paramMinecraftServer);
    this.e = paramMinecraftServer.d.a("max-players", 20);
    e();
    g();
    i();
    f();
    h();
    j();
  }

  public void a(ee paramee)
  {
    this.l = new cl(new File(paramee.s, "players"));
  }

  public int a()
  {
    return this.d.b();
  }

  public void a(ea paramea)
  {
    this.b.add(paramea);
    this.l.b(paramea);
    this.c.e.y.d((int)paramea.l >> 4, (int)paramea.n >> 4);
    while (this.c.e.a(paramea, paramea.v).size() != 0)
      paramea.a(paramea.l, paramea.m + 1.0D, paramea.n);
    this.c.e.a(paramea);
    this.d.a(paramea);
    for (String str : etc.getInstance().getMotd())
      paramea.a.b(new ba(str));
    etc.getLoader().callHook(PluginLoader.Hook.LOGIN, new Object[] { paramea });
  }

  public void b(ea paramea)
  {
    try
    {
      this.d.c(paramea);
    }
    catch (NullPointerException localNullPointerException)
    {
      a.info("What?");
    }
  }

  public void c(ea paramea)
  {
    this.d.b(paramea);
    this.l.a(paramea);
    this.c.e.d(paramea);
    this.b.remove(paramea);
  }

  public ea a(ew paramew, String paramString1, String paramString2)
  {
    if (this.f.contains(paramString1.trim().toLowerCase()))
    {
      paramew.b("You are banned from this server!");
      return null;
    }
    ea localea1 = new ea(this.c, this.c.e, paramString1, new in(this.c.e));
    Player localPlayer = localea1.getPlayer();
    String str1 = paramew.b.b().toString().split(":")[0].substring(1);
    if (this.g.contains(str1))
    {
      paramew.b("Your IP address is banned from this server!");
      return null;
    }
    for (int m = 0; m < this.b.size(); m++)
    {
      ea localea2 = (ea)this.b.get(m);
      if (!localea2.aq.equalsIgnoreCase(paramString1))
        continue;
      String str3 = localea2.a.b.b().toString().split(":")[0].substring(1);
      if (str3.equals(str1))
        localea2.a.b("You logged in from another location.");
      else
        paramew.b("You are currently logged in.");
    }
    if ((etc.getInstance().isWhitelistEnabled()) && (!etc.getDataSource().isUserOnWhitelist(paramString1)) && (!localPlayer.isAdmin()))
    {
      paramew.b(etc.getInstance().getWhitelistMessage());
      return null;
    }
    if ((this.b.size() >= this.e) && ((!etc.getDataSource().hasReserveList()) || ((!localPlayer.isAdmin()) && (!etc.getDataSource().isUserOnReserveList(paramString1)))))
    {
      paramew.b("Server is full.");
      return null;
    }
    if (!localPlayer.getIps()[0].equals(""))
    {
      m = 1;
      for (int n = 0; n < localPlayer.getIps().length; n++)
      {
        if ((localPlayer.getIps()[n].equals("")) || (!str1.equals(localPlayer.getIps()[n])))
          continue;
        m = 0;
      }
      if (m != 0)
      {
        paramew.b("IP doesn't match specified IP.");
        return null;
      }
    }
    Object localObject = etc.getLoader().callHook(PluginLoader.Hook.LOGINCHECK, new Object[] { paramString1 });
    if ((localObject instanceof String))
    {
      String str2 = (String)localObject;
      if ((str2 != null) && (!str2.equals("")))
      {
        paramew.b(str2);
        return null;
      }
    }
    return localea1;
  }

  public String getBans()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int m = 0; m < this.f.size(); m++)
    {
      if (m > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(this.f.get(m));
    }
    return localStringBuilder.toString();
  }

  public String getIpBans()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int m = 0; m < this.g.size(); m++)
    {
      if (m > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(this.g.get(m));
    }
    return localStringBuilder.toString();
  }

  public void b()
  {
    this.d.a();
  }

  public void a(int paramInt1, int paramInt2, int paramInt3)
  {
    this.d.a(paramInt1, paramInt2, paramInt3);
  }

  public void a(hp paramhp)
  {
    for (int m = 0; m < this.b.size(); m++)
    {
      ea localea = (ea)this.b.get(m);
      localea.a.b(paramhp);
    }
  }

  public String c()
  {
    String str = "";
    for (int m = 0; m < this.b.size(); m++)
    {
      if (m > 0)
        str = new StringBuilder().append(str).append(", ").toString();
      str = new StringBuilder().append(str).append(((ea)this.b.get(m)).aq).toString();
    }
    return str;
  }

  public void a(String paramString)
  {
    this.f.add(paramString.toLowerCase());
    f();
  }

  public void b(String paramString)
  {
    this.f.remove(paramString.toLowerCase());
    f();
  }

  private void e()
  {
    try
    {
      this.f.clear();
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.i));
      String str = "";
      while ((str = localBufferedReader.readLine()) != null)
        this.f.add(str.trim().toLowerCase());
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to load ban list: ").append(localException).toString());
    }
  }

  private void f()
  {
    try
    {
      PrintWriter localPrintWriter = new PrintWriter(new FileWriter(this.i, false));
      Iterator localIterator = this.f.iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        localPrintWriter.println(localObject);
      }
      localPrintWriter.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to save ban list: ").append(localException).toString());
    }
  }

  public void c(String paramString)
  {
    this.g.add(paramString.toLowerCase());
    h();
  }

  public void d(String paramString)
  {
    this.g.remove(paramString.toLowerCase());
    h();
  }

  private void g()
  {
    try
    {
      this.g.clear();
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.j));
      String str = "";
      while ((str = localBufferedReader.readLine()) != null)
        this.g.add(str.trim().toLowerCase());
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to load ip ban list: ").append(localException).toString());
    }
  }

  private void h()
  {
    try
    {
      PrintWriter localPrintWriter = new PrintWriter(new FileWriter(this.j, false));
      Iterator localIterator = this.g.iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        localPrintWriter.println(localObject);
      }
      localPrintWriter.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to save ip ban list: ").append(localException).toString());
    }
  }

  public void e(String paramString)
  {
    this.h.add(paramString.toLowerCase());
    j();
  }

  public void f(String paramString)
  {
    this.h.remove(paramString.toLowerCase());
    j();
  }

  private void i()
  {
    try
    {
      this.h.clear();
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.k));
      String str = "";
      while ((str = localBufferedReader.readLine()) != null)
        this.h.add(str.trim().toLowerCase());
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to load ip ban list: ").append(localException).toString());
    }
  }

  private void j()
  {
    try
    {
      PrintWriter localPrintWriter = new PrintWriter(new FileWriter(this.k, false));
      Iterator localIterator = this.h.iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        localPrintWriter.println(localObject);
      }
      localPrintWriter.close();
    }
    catch (Exception localException)
    {
      a.warning(new StringBuilder().append("Failed to save ip ban list: ").append(localException).toString());
    }
  }

  public boolean g(String paramString)
  {
    return this.h.contains(paramString.trim().toLowerCase());
  }

  public ea h(String paramString)
  {
    for (int m = 0; m < this.b.size(); m++)
    {
      ea localea = (ea)this.b.get(m);
      if (localea.aq.equalsIgnoreCase(paramString))
        return localea;
    }
    return null;
  }

  public void a(String paramString1, String paramString2)
  {
    ea localea = h(paramString1);
    if (localea != null)
      localea.a.b(new ba(paramString2));
  }

  public void i(String paramString)
  {
    ba localba = new ba(paramString);
    for (int m = 0; m < this.b.size(); m++)
    {
      ea localea = (ea)this.b.get(m);
      if (!g(localea.aq))
        continue;
      localea.a.b(localba);
    }
  }

  public boolean a(String paramString, hp paramhp)
  {
    ea localea = h(paramString);
    if (localea != null)
    {
      localea.a.b(paramhp);
      return true;
    }
    return false;
  }

  public void a(int paramInt1, int paramInt2, int paramInt3, as paramas)
  {
    this.d.a(new ib(paramInt1, paramInt2, paramInt3, paramas), paramInt1, paramInt2, paramInt3);
  }

  public void d()
  {
    for (int m = 0; m < this.b.size(); m++)
      this.l.a((ea)this.b.get(m));
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     ft
 * JD-Core Version:    0.6.0
 */