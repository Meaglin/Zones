import java.util.ArrayList;
import java.util.Iterator;

public class Player extends BaseEntity
{
  private ea user;
  private int id = -1;
  private String prefix = "";
  private String[] commands = { "" };
  private ArrayList<String> groups = new ArrayList();
  private String[] ips = { "" };
  private boolean ignoreRestrictions = false;
  private boolean admin = false;
  private boolean canModifyWorld = false;
  private boolean muted = false;
  private Inventory inventory;
  private Inventory craftingTable;
  private Inventory equipment;

  public void kick(String paramString)
  {
    this.user.a.c(paramString);
  }

  public void sendMessage(String paramString)
  {
    this.user.a.msg(paramString);
  }

  public void giveItem(Item paramItem)
  {
    giveItem(paramItem.getItemId(), paramItem.getAmount());
  }

  public void giveItem(int paramInt1, int paramInt2)
  {
    this.inventory.giveItem(paramInt1, paramInt2);
    this.inventory.updateInventory();
  }

  public void giveItemDrop(Item paramItem)
  {
    giveItemDrop(paramItem.getItemId(), paramItem.getAmount());
  }

  public void giveItemDrop(int paramInt1, int paramInt2)
  {
    if (paramInt2 == -1)
    {
      this.user.a(new gp(paramInt1, 255));
    }
    else
    {
      int i = paramInt2;
      do
      {
        if (i - 64 >= 64)
          this.user.a(new gp(paramInt1, 64));
        else
          this.user.a(new gp(paramInt1, i));
        i -= 64;
      }
      while (i > 0);
    }
  }

  public boolean canUseCommand(String paramString)
  {
    for (Object localObject2 : this.commands)
      if (localObject2.equalsIgnoreCase(paramString))
        return true;
    ??? = this.groups.iterator();
    while (((Iterator)???).hasNext())
    {
      String str = (String)((Iterator)???).next();
      Group localGroup = etc.getDataSource().getGroup(str);
      if ((localGroup != null) && (recursiveUseCommand(localGroup, paramString)))
        return true;
    }
    if (hasNoGroups())
    {
      ??? = etc.getInstance().getDefaultGroup();
      if ((??? != null) && (recursiveUseCommand((Group)???, paramString)))
        return true;
    }
    return false;
  }

  private boolean recursiveUseCommand(Group paramGroup, String paramString)
  {
    String str;
    for (str : paramGroup.Commands)
      if ((str.equalsIgnoreCase(paramString)) || (str.equals("*")))
        return true;
    if (paramGroup.InheritedGroups != null)
      for (str : paramGroup.InheritedGroups)
      {
        Group localGroup = etc.getDataSource().getGroup(str);
        if ((localGroup != null) && (recursiveUseCommand(localGroup, paramString)))
          return true;
      }
    return false;
  }

  public boolean isInGroup(String paramString)
  {
    if ((paramString != null) && (etc.getInstance().getDefaultGroup() != null) && (paramString.equalsIgnoreCase(etc.getInstance().getDefaultGroup().Name)))
      return true;
    Iterator localIterator = this.groups.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (recursiveUserInGroup(etc.getDataSource().getGroup(str), paramString))
        return true;
    }
    return false;
  }

  private boolean recursiveUserInGroup(Group paramGroup, String paramString)
  {
    if ((paramGroup == null) || (paramString == null))
      return false;
    if (paramGroup.Name.equalsIgnoreCase(paramString))
      return true;
    if (paramGroup.InheritedGroups != null)
      for (String str : paramGroup.InheritedGroups)
      {
        if (paramGroup.Name.equalsIgnoreCase(str))
          return true;
        Group localGroup = etc.getDataSource().getGroup(str);
        if ((localGroup != null) && (recursiveUserInGroup(localGroup, paramString)))
          return true;
      }
    return false;
  }

  public boolean hasControlOver(Player paramPlayer)
  {
    int i = 0;
    if (paramPlayer.hasNoGroups())
      return true;
    for (String str : paramPlayer.getGroups())
    {
      if (!isInGroup(str))
        continue;
      i = 1;
      break;
    }
    return i;
  }

  public String getName()
  {
    return this.user.aq;
  }

  public Location getLocation()
  {
    Location localLocation = new Location();
    localLocation.x = getX();
    localLocation.y = getY();
    localLocation.z = getZ();
    localLocation.rotX = getRotation();
    localLocation.rotY = getPitch();
    return localLocation;
  }

  public String getIP()
  {
    return this.user.a.b.b().toString().split(":")[0].substring(1);
  }

  public boolean isAdmin()
  {
    if (this.admin)
      return true;
    Iterator localIterator = this.groups.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Group localGroup = etc.getDataSource().getGroup(str);
      if ((localGroup != null) && (localGroup.Administrator))
        return true;
    }
    return false;
  }

  public boolean getAdmin()
  {
    return this.admin;
  }

  public void setAdmin(boolean paramBoolean)
  {
    this.admin = paramBoolean;
  }

  public boolean canBuild()
  {
    if (this.canModifyWorld)
      return true;
    Iterator localIterator = this.groups.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Group localGroup = etc.getDataSource().getGroup(str);
      if ((localGroup != null) && (localGroup.CanModifyWorld))
        return true;
    }
    return (hasNoGroups()) && (etc.getInstance().getDefaultGroup().CanModifyWorld);
  }

  public boolean canModifyWorld()
  {
    return this.canModifyWorld;
  }

  public void setCanModifyWorld(boolean paramBoolean)
  {
    this.canModifyWorld = paramBoolean;
  }

  public String[] getCommands()
  {
    return this.commands;
  }

  public void setCommands(String[] paramArrayOfString)
  {
    this.commands = paramArrayOfString;
  }

  public String[] getGroups()
  {
    String[] arrayOfString = new String[this.groups.size()];
    this.groups.toArray(arrayOfString);
    return arrayOfString;
  }

  public void setGroups(String[] paramArrayOfString)
  {
    this.groups.clear();
    for (String str : paramArrayOfString)
    {
      if (str.length() <= 0)
        continue;
      this.groups.add(str);
    }
  }

  public void addGroup(String paramString)
  {
    this.groups.add(paramString);
  }

  public int getSqlId()
  {
    return this.id;
  }

  public void setSqlId(int paramInt)
  {
    this.id = paramInt;
  }

  public boolean canIgnoreRestrictions()
  {
    if ((this.admin) || (this.ignoreRestrictions))
      return true;
    Iterator localIterator = this.groups.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Group localGroup = etc.getDataSource().getGroup(str);
      if ((localGroup != null) && ((localGroup.Administrator) || (localGroup.IgnoreRestrictions)))
        return true;
    }
    return false;
  }

  public boolean ignoreRestrictions()
  {
    return this.ignoreRestrictions;
  }

  public void setIgnoreRestrictions(boolean paramBoolean)
  {
    this.ignoreRestrictions = paramBoolean;
  }

  public String[] getIps()
  {
    return this.ips;
  }

  public void setIps(String[] paramArrayOfString)
  {
    this.ips = paramArrayOfString;
  }

  public String getColor()
  {
    if ((this.prefix != null) && (!this.prefix.equals("")))
      return "§" + this.prefix;
    if (this.groups.size() > 0)
    {
      localGroup = etc.getDataSource().getGroup((String)this.groups.get(0));
      if (localGroup != null)
        return "§" + localGroup.Prefix;
    }
    Group localGroup = etc.getInstance().getDefaultGroup();
    return localGroup != null ? "§" + localGroup.Prefix : "";
  }

  public String getPrefix()
  {
    return this.prefix;
  }

  public void setPrefix(String paramString)
  {
    this.prefix = paramString;
  }

  public ea getUser()
  {
    return this.user;
  }

  public void setUser(ea paramea)
  {
    this.user = paramea;
    this.entity = paramea;
    this.inventory = new Inventory(this, Inventory.Type.Inventory);
    this.craftingTable = new Inventory(this, Inventory.Type.CraftingTable);
    this.equipment = new Inventory(this, Inventory.Type.Equipment);
  }

  public void teleportTo(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2)
  {
    this.user.a.a(paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2);
  }

  public void setHealth(int paramInt)
  {
  }

  public boolean isMuted()
  {
    return this.muted;
  }

  public boolean toggleMute()
  {
    this.muted = (!this.muted);
    return this.muted;
  }

  public boolean hasNoGroups()
  {
    if (this.groups.isEmpty())
      return true;
    if (this.groups.size() == 1)
      return ((String)this.groups.get(0)).equals("");
    return false;
  }

  public int getItemInHand()
  {
    return this.user.a.getItemInHand();
  }

  public Inventory getInventory()
  {
    return this.inventory;
  }

  public Inventory getCraftingTable()
  {
    return this.craftingTable;
  }

  public Inventory getEquipment()
  {
    return this.equipment;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Player
 * JD-Core Version:    0.6.0
 */