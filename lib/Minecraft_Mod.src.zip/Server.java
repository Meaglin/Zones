import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.server.MinecraftServer;

public class Server
{
  private MinecraftServer server;

  public Server(MinecraftServer paramMinecraftServer)
  {
    this.server = paramMinecraftServer;
  }

  public void useConsoleCommand(String paramString)
  {
    this.server.a(paramString, this.server);
  }

  public void useConsoleCommand(String paramString, Player paramPlayer)
  {
    this.server.a(paramString, paramPlayer.getUser().a);
  }

  public void setTimer(String paramString, int paramInt)
  {
    MinecraftServer.b.put(paramString, Integer.valueOf(paramInt));
  }

  public boolean isTimerExpired(String paramString)
  {
    return MinecraftServer.b.containsKey(paramString);
  }

  public long getTime()
  {
    return this.server.e.c;
  }

  public void setTime(long paramLong)
  {
    this.server.e.c = paramLong;
  }

  public MinecraftServer getMCServer()
  {
    return this.server;
  }

  public Player matchPlayer(String paramString)
  {
    Object localObject = null;
    int i = 0;
    int j;
    ea localea;
    if (("`" + this.server.f.c().toUpperCase() + "`").split(paramString.toUpperCase()).length == 2)
      for (j = 0; (j < this.server.f.b.size()) && (i == 0); j++)
      {
        localea = (ea)this.server.f.b.get(j);
        if (("`" + localea.aq.toUpperCase() + "`").split(paramString.toUpperCase()).length != 2)
          continue;
        localObject = localea;
        i = 1;
      }
    else if (("`" + this.server.f.c() + "`").split(paramString).length > 2)
      for (j = 0; (j < this.server.f.b.size()) && (i == 0); j++)
      {
        localea = (ea)this.server.f.b.get(j);
        if (!localea.aq.equalsIgnoreCase(paramString))
          continue;
        localObject = localea;
        i = 1;
      }
    return localObject != null ? localObject.getPlayer() : null;
  }

  public Player getPlayer(String paramString)
  {
    ea localea = this.server.f.h(paramString);
    return localea == null ? null : localea.getPlayer();
  }

  public List<Player> getPlayerList()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.server.f.b.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(((ea)localObject).getPlayer());
    }
    return localArrayList;
  }

  public List<Mob> getMobList()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.server.e.a.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof gh))
        localArrayList.add(new Mob((gh)localObject));
    }
    return localArrayList;
  }

  public Location getSpawnLocation()
  {
    Location localLocation = new Location();
    localLocation.x = (this.server.e.n + 0.5D);
    localLocation.y = (this.server.e.d(this.server.e.n, this.server.e.p) + 1.5D);
    localLocation.z = (this.server.e.p + 0.5D);
    localLocation.rotX = 0.0F;
    localLocation.rotY = 0.0F;
    return localLocation;
  }

  public void setBlock(Block paramBlock)
  {
    setBlockData(paramBlock.getX(), paramBlock.getY(), paramBlock.getZ(), paramBlock.getData());
    setBlockAt(paramBlock.getType(), paramBlock.getX(), paramBlock.getY(), paramBlock.getZ());
  }

  public Block getBlockAt(int paramInt1, int paramInt2, int paramInt3)
  {
    return new Block(getBlockIdAt(paramInt1, paramInt2, paramInt3), paramInt1, paramInt2, paramInt3, getBlockData(paramInt1, paramInt2, paramInt3));
  }

  public int getBlockData(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.server.e.b(paramInt1, paramInt2, paramInt3);
  }

  public boolean setBlockData(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool = this.server.e.c(paramInt1, paramInt2, paramInt3, paramInt4);
    etc.getMCServer().f.a(new et(paramInt1, paramInt2, paramInt3, etc.getMCServer().e));
    ComplexBlock localComplexBlock = getComplexBlock(paramInt1, paramInt2, paramInt3);
    if (localComplexBlock != null)
      localComplexBlock.update();
    return bool;
  }

  public void setBlockAt(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.server.e.d(paramInt2, paramInt3, paramInt4, paramInt1);
  }

  public int getHighestBlockY(int paramInt1, int paramInt2)
  {
    return this.server.e.d(paramInt1, paramInt2);
  }

  public int getBlockIdAt(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.server.e.a(paramInt1, paramInt2, paramInt3);
  }

  public ComplexBlock getComplexBlock(int paramInt1, int paramInt2, int paramInt3)
  {
    as localas = this.server.e.k(paramInt1, paramInt2, paramInt3);
    if (localas != null)
    {
      if ((localas instanceof hb))
        return new Chest((hb)localas);
      if ((localas instanceof ig))
        return new Sign((ig)localas);
      if ((localas instanceof df))
        return new Furnace((df)localas);
    }
    return null;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Server
 * JD-Core Version:    0.6.0
 */