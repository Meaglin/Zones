public abstract class ItemArray
{
  public void addItem(Item paramItem)
  {
    if (paramItem == null)
      return;
    int i = paramItem.getSlot();
    if ((i < getArray().length) && (i >= 0))
    {
      if (paramItem.getAmount() <= 0)
        getArray()[i] = null;
      else if (Item.isValidItem(paramItem.getItemId()))
        getArray()[i] = new gp(paramItem.getItemId(), paramItem.getAmount());
    }
    else if (i == -1)
    {
      int j = getEmptySlot();
      if (j != -1)
      {
        getArray()[j] = new gp(paramItem.getItemId(), paramItem.getAmount());
        paramItem.setSlot(j);
      }
    }
  }

  public Item getItemFromSlot(int paramInt)
  {
    if ((paramInt < getArray().length) && (paramInt >= 0) && (getArray()[paramInt] != null))
      return new Item(getArray()[paramInt].c, getArray()[paramInt].a, paramInt);
    return null;
  }

  public Item getItemFromId(int paramInt)
  {
    for (int i = 0; getArray().length > i; i++)
      if ((getArray()[i] != null) && (getArray()[i].c == paramInt))
        return new Item(getArray()[i].c, getArray()[i].a, i);
    return null;
  }

  public Item getItemFromId(int paramInt1, int paramInt2)
  {
    for (int i = 0; getArray().length > i; i++)
      if ((getArray()[i] != null) && (getArray()[i].c == paramInt1) && (getArray()[i].a <= paramInt2))
        return new Item(getArray()[i].c, getArray()[i].a, i);
    return null;
  }

  public int getEmptySlot()
  {
    for (int i = 0; getArray().length > i; i++)
      if (getArray()[i] == null)
        return i;
    return -1;
  }

  public void removeItem(int paramInt)
  {
    if ((paramInt < getArray().length) && (paramInt >= 0))
      getArray()[paramInt] = null;
  }

  public void removeItem(Item paramItem)
  {
    int i = paramItem.getAmount();
    int j = paramItem.getItemId();
    for (int k = 0; getArray().length > k; k++)
    {
      if ((getArray()[k] == null) || (getArray()[k].c != j))
        continue;
      int m = getArray()[k].a;
      m -= i;
      i -= getArray()[k].a;
      if (m <= 0)
        getArray()[k] = null;
      else
        getArray()[k].a = m;
      if (i <= 0)
        return;
    }
  }

  public boolean hasItem(int paramInt1, int paramInt2, int paramInt3)
  {
    for (int i = 0; getArray().length > i; i++)
      if ((getArray()[i] != null) && (getArray()[i].c == paramInt1) && (getArray()[i].a >= paramInt2) && (getArray()[i].a <= paramInt3))
        return true;
    return false;
  }

  public void clearContents()
  {
    for (int i = 0; getArray().length > i; i++)
      getArray()[i] = null;
  }

  public abstract gp[] getArray();
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     ItemArray
 * JD-Core Version:    0.6.0
 */