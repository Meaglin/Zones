import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;

public class id extends ej
  implements ef
{
  public static final Logger a = Logger.getLogger("Minecraft");
  public bb b;
  public boolean c = false;
  private MinecraftServer d;
  private ea e;
  private int f = 0;
  private double g;
  private double h;
  private double i;
  private boolean j = true;
  private gp k = null;
  private List<String> onlyOneUseKits = new ArrayList();

  public id(MinecraftServer paramMinecraftServer, bb parambb, ea paramea)
  {
    this.d = paramMinecraftServer;
    this.b = parambb;
    parambb.a(this);
    this.e = paramea;
    paramea.a = this;
  }

  public int getItemInHand()
  {
    if (this.k != null)
      return this.k.c;
    return -1;
  }

  public Player getPlayer()
  {
    return this.e.getPlayer();
  }

  public void a()
  {
    this.b.a();
    if (this.f++ % 20 == 0)
      this.b.a(new iz());
  }

  public void c(String paramString)
  {
    this.b.a(new io(paramString));
    this.b.c();
    this.d.f.c(this.e);
    this.c = true;
  }

  public void a(gf paramgf)
  {
    double d1;
    if (!this.j)
    {
      d1 = paramgf.b - this.h;
      if ((paramgf.a == this.g) && (d1 * d1 < 0.01D) && (paramgf.c == this.i))
        this.j = true;
    }
    if (((int)Math.floor(this.g) != (int)Math.floor(this.e.l)) || ((int)Math.floor(this.h) != (int)Math.floor(this.e.m)) || ((int)Math.floor(this.i) != (int)Math.floor(this.e.n)))
    {
      Location localLocation1 = new Location();
      localLocation1.x = (int)Math.floor(this.g);
      localLocation1.y = (int)Math.floor(this.h);
      localLocation1.z = (int)Math.floor(this.i);
      localLocation1.rotX = this.e.r;
      localLocation1.rotY = this.e.s;
      Location localLocation2 = new Location();
      localLocation2.x = (int)Math.floor(this.e.l);
      localLocation2.y = (int)Math.floor(this.e.m);
      localLocation2.z = (int)Math.floor(this.e.n);
      localLocation2.rotX = this.e.r;
      localLocation2.rotY = this.e.s;
      etc.getLoader().callHook(PluginLoader.Hook.PLAYER_MOVE, new Object[] { this.e, localLocation1, localLocation2 });
    }
    if (this.j)
    {
      this.g = this.e.l;
      this.h = this.e.m;
      this.i = this.e.n;
      d1 = this.e.l;
      double d2 = this.e.m;
      double d3 = this.e.n;
      float f1 = this.e.r;
      float f2 = this.e.s;
      if (paramgf.h)
      {
        d1 = paramgf.a;
        d2 = paramgf.b;
        d3 = paramgf.c;
        d4 = paramgf.d - paramgf.b;
        if ((d4 > 1.65D) || (d4 < 0.1D))
        {
          c("Illegal stance");
          a.warning(new StringBuilder().append(getPlayer().getName()).append(" had an illegal stance: ").append(d4).toString());
        }
        this.e.ai = paramgf.d;
      }
      if (paramgf.i)
      {
        f1 = paramgf.e;
        f2 = paramgf.f;
      }
      this.e.i();
      this.e.M = 0.0F;
      this.e.b(this.g, this.h, this.i, f1, f2);
      double d4 = d1 - this.e.l;
      double d5 = d2 - this.e.m;
      double d6 = d3 - this.e.n;
      float f3 = 0.0625F;
      int m = this.d.e.a(this.e, this.e.v.b().e(f3, f3, f3)).size() == 0 ? 1 : 0;
      this.e.c(d4, d5, d6);
      d4 = d1 - this.e.l;
      d5 = d2 - this.e.m;
      if ((d5 > -0.5D) || (d5 < 0.5D))
        d5 = 0.0D;
      d6 = d3 - this.e.n;
      double d7 = d4 * d4 + d5 * d5 + d6 * d6;
      int n = 0;
      if (d7 > 0.0625D)
      {
        n = 1;
        a.warning(new StringBuilder().append(getPlayer().getName()).append(" moved wrongly!").toString());
      }
      this.e.b(d1, d2, d3, f1, f2);
      int i1 = this.d.e.a(this.e, this.e.v.b().e(f3, f3, f3)).size() == 0 ? 1 : 0;
      if ((m != 0) && ((n != 0) || (i1 == 0)))
      {
        a(this.g, this.h, this.i, f1, f2);
        return;
      }
      this.e.w = paramgf.g;
      this.d.f.b(this.e);
    }
  }

  public void a(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2)
  {
    Location localLocation = new Location();
    localLocation.x = paramDouble1;
    localLocation.y = paramDouble2;
    localLocation.z = paramDouble3;
    localLocation.rotX = paramFloat1;
    localLocation.rotY = paramFloat2;
    if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.TELEPORT, new Object[] { this.e, this.e.getPlayer().getLocation(), localLocation })).booleanValue())
      return;
    this.j = false;
    this.g = paramDouble1;
    this.h = paramDouble2;
    this.i = paramDouble3;
    this.e.b(paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2);
    this.e.a.b(new dq(paramDouble1, paramDouble2 + 1.620000004768372D, paramDouble2, paramDouble3, paramFloat1, paramFloat2, false));
  }

  public void a(hd paramhd)
  {
    this.e.aj.a[this.e.aj.d] = this.k;
    int m = this.d.e.z = (this.d.f.g(getPlayer().getName())) || (getPlayer().isAdmin()) ? 1 : 0;
    int n = 0;
    if (paramhd.e == 0)
      n = 1;
    if (paramhd.e == 1)
      n = 1;
    if (n != 0)
    {
      double d1 = this.e.m;
      this.e.m = this.e.ai;
      fr localfr = this.e.a(4.0D, 1.0F);
      this.e.m = d1;
      if (localfr == null)
        return;
      if ((localfr.b != paramhd.a) || (localfr.c != paramhd.b) || (localfr.d != paramhd.c) || (localfr.e != paramhd.d))
        return;
    }
    int i1 = paramhd.a;
    int i2 = paramhd.b;
    int i3 = paramhd.c;
    int i4 = paramhd.d;
    int i5 = (int)gj.e(i1 - this.d.e.n);
    int i6 = (int)gj.e(i3 - this.d.e.p);
    if (i5 > i6)
      i6 = i5;
    Block localBlock;
    if (paramhd.e == 0)
    {
      if (!getPlayer().canBuild())
        return;
      if ((i6 > etc.getInstance().getSpawnProtectionSize()) || (m != 0))
      {
        localBlock = etc.getServer().getBlockAt(i1, i2, i3);
        localBlock.setStatus(0);
        if (!((Boolean)etc.getLoader().callHook(PluginLoader.Hook.BLOCK_DESTROYED, new Object[] { this.e, localBlock })).booleanValue())
          this.e.ad.a(i1, i2, i3);
      }
    }
    else if (paramhd.e == 2)
    {
      localBlock = etc.getServer().getBlockAt(i1, i2, i3);
      localBlock.setStatus(2);
      etc.getLoader().callHook(PluginLoader.Hook.BLOCK_DESTROYED, new Object[] { this.e, localBlock });
      this.e.ad.a();
    }
    else if (paramhd.e == 1)
    {
      if (!getPlayer().canBuild())
        return;
      if ((i6 > etc.getInstance().getSpawnProtectionSize()) || (m != 0))
      {
        localBlock = etc.getServer().getBlockAt(i1, i2, i3);
        localBlock.setStatus(1);
        if (!((Boolean)etc.getLoader().callHook(PluginLoader.Hook.BLOCK_DESTROYED, new Object[] { this.e, localBlock })).booleanValue())
          this.e.ad.a(i1, i2, i3, i4);
      }
    }
    else if (paramhd.e == 3)
    {
      localBlock = etc.getServer().getBlockAt(i1, i2, i3);
      localBlock.setStatus(3);
      etc.getLoader().callHook(PluginLoader.Hook.BLOCK_DESTROYED, new Object[] { this.e, localBlock });
      double d2 = this.e.l - (i1 + 0.5D);
      double d3 = this.e.m - (i2 + 0.5D);
      double d4 = this.e.n - (i3 + 0.5D);
      double d5 = d2 * d2 + d3 * d3 + d4 * d4;
      if (d5 < 256.0D)
        this.e.a.b(new et(i1, i2, i3, this.d.e));
    }
    this.d.e.z = false;
  }

  public void a(fe paramfe)
  {
    if (!getPlayer().canBuild())
      return;
    int m = this.d.e.z = (this.d.f.g(getPlayer().getName())) || (getPlayer().isAdmin()) ? 1 : 0;
    int n = paramfe.b;
    int i1 = paramfe.c;
    int i2 = paramfe.d;
    int i3 = paramfe.e;
    int i4 = (int)gj.e(n - this.d.e.n);
    int i5 = (int)gj.e(i2 - this.d.e.p);
    if (i4 > i5)
      i5 = i4;
    if ((i5 > etc.getInstance().getSpawnProtectionSize()) || (m != 0))
    {
      gp localgp = paramfe.a >= 0 ? new gp(paramfe.a) : null;
      Block localBlock1 = new Block(localgp != null ? localgp.c : paramfe.a, n, i1, i2);
      if (paramfe.e == 0)
        localBlock1.setY(localBlock1.getY() - 1);
      else if (paramfe.e == 1)
        localBlock1.setY(localBlock1.getY() + 1);
      else if (paramfe.e == 2)
        localBlock1.setZ(localBlock1.getZ() - 1);
      else if (paramfe.e == 3)
        localBlock1.setZ(localBlock1.getZ() + 1);
      else if (paramfe.e == 4)
        localBlock1.setX(localBlock1.getX() - 1);
      else if (paramfe.e == 5)
        localBlock1.setX(localBlock1.getX() + 1);
      Block localBlock2 = new Block(etc.getServer().getBlockIdAt(n, i1, i2), n, i1, i2);
      localBlock2.setFaceClicked(Block.Face.fromId(paramfe.e));
      if (!((Boolean)etc.getLoader().callHook(PluginLoader.Hook.BLOCK_CREATED, new Object[] { this.e, localBlock1, localBlock2, Integer.valueOf(paramfe.a) })).booleanValue())
        if (localgp != null)
        {
          if ((!etc.getInstance().isOnItemBlacklist(localgp.c)) || (m != 0))
            this.e.ad.a(this.e, this.d.e, localgp, n, i1, i2, i3);
        }
        else
          this.e.ad.a(this.e, this.d.e, localgp, n, i1, i2, i3);
    }
    this.e.a.b(new et(n, i1, i2, this.d.e));
    this.d.e.z = false;
  }

  public void a(String paramString)
  {
    etc.getLoader().callHook(PluginLoader.Hook.DISCONNECT, new Object[] { this.e });
    a.info(new StringBuilder().append(getPlayer().getName()).append(" lost connection: ").append(paramString).toString());
    this.d.f.c(this.e);
    this.c = true;
  }

  public void a(hp paramhp)
  {
    a.warning(new StringBuilder().append(getClass()).append(" wasn't prepared to deal with a ").append(paramhp.getClass()).toString());
    c("Protocol error, unexpected packet");
  }

  public void b(hp paramhp)
  {
    this.b.a(paramhp);
  }

  public void a(fv paramfv)
  {
    int m = paramfv.b;
    this.e.aj.d = (this.e.aj.a.length - 1);
    if (m == 0)
      this.k = null;
    else
      this.k = new gp(m);
    this.e.aj.a[this.e.aj.d] = this.k;
    this.d.k.a(this.e, new fv(this.e.c, m));
  }

  public void a(k paramk)
  {
    double d1 = paramk.b / 32.0D;
    double d2 = paramk.c / 32.0D;
    double d3 = paramk.d / 32.0D;
    fn localfn = new fn(this.d.e, d1, d2, d3, new gp(paramk.h, paramk.i));
    localfn.o = (paramk.e / 128.0D);
    localfn.p = (paramk.f / 128.0D);
    localfn.q = (paramk.g / 128.0D);
    localfn.ad = 10;
    this.d.e.a(localfn);
  }

  public void a(ba paramba)
  {
    String str1 = paramba.a;
    if (str1.length() > 100)
    {
      b("Chat message too long");
      return;
    }
    str1 = str1.trim();
    for (int m = 0; m < str1.length(); m++)
    {
      if (" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~¦ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»".indexOf(str1.charAt(m)) >= 0)
        continue;
      b("Illegal characters in chat");
      return;
    }
    if (str1.startsWith("/"))
    {
      d(str1);
    }
    else
    {
      if (getPlayer().isMuted())
      {
        msg("§cYou are currently muted.");
        return;
      }
      if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.CHAT, new Object[] { this.e, str1 })).booleanValue())
        return;
      String str2 = new StringBuilder().append("<").append(getPlayer().getColor()).append(getPlayer().getName()).append("§f").append("> ").append(str1).toString();
      a.log(Level.INFO, new StringBuilder().append("<").append(getPlayer().getName()).append("> ").append(str1).toString());
      this.d.f.a(new ba(str2));
    }
  }

  public void msg(String paramString)
  {
    b(new ba(paramString));
  }

  private void d(String paramString)
  {
    try
    {
      if (etc.getInstance().isLogging())
        a.info(new StringBuilder().append("Command used by ").append(getPlayer().getName()).append(" ").append(paramString).toString());
      String[] arrayOfString1 = paramString.split(" ");
      if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.COMMAND, new Object[] { this.e, arrayOfString1 })).booleanValue())
        return;
      if ((!getPlayer().canUseCommand(arrayOfString1[0])) && (!arrayOfString1[0].startsWith("/#")))
      {
        if (etc.getInstance().showUnknownCommand())
          msg("§cUnknown command.");
        return;
      }
      Object localObject1;
      Object localObject8;
      if (arrayOfString1[0].equalsIgnoreCase("/help"))
      {
        localObject1 = new ArrayList();
        Iterator localIterator = etc.getInstance().getCommands().entrySet().iterator();
        while (localIterator.hasNext())
        {
          localObject8 = (Map.Entry)localIterator.next();
          if (getPlayer().canUseCommand((String)((Map.Entry)localObject8).getKey()))
          {
            if (((((String)((Map.Entry)localObject8).getKey()).equals("/kit")) && (!etc.getDataSource().hasKits())) || ((((String)((Map.Entry)localObject8).getKey()).equals("/listwarps")) && (!etc.getDataSource().hasWarps())))
              continue;
            ((List)localObject1).add(new StringBuilder().append((String)((Map.Entry)localObject8).getKey()).append(" ").append((String)((Map.Entry)localObject8).getValue()).toString());
          }
        }
        msg(new StringBuilder().append("§3Available commands (Page ").append(arrayOfString1.length == 2 ? arrayOfString1[1] : "1").append(" of ").append((int)Math.ceil(((List)localObject1).size() / 7.0D)).append(") [] = required <> = optional:").toString());
        if (arrayOfString1.length == 2)
          try
          {
            Object localObject5 = Integer.parseInt(arrayOfString1[1]);
            if (localObject5 > 0)
              localObject5 = (localObject5 - 1) * 7;
            else
              localObject5 = 0;
            for (localObject8 = localObject5; localObject8 < localObject5 + 7; localObject8++)
            {
              if (((List)localObject1).size() <= localObject8)
                continue;
              msg(new StringBuilder().append("§c").append((String)((List)localObject1).get(localObject8)).toString());
            }
          }
          catch (NumberFormatException localNumberFormatException2)
          {
            msg("§cNot a valid page number.");
          }
        else
          for (int i2 = 0; i2 < 7; i2++)
          {
            if (((List)localObject1).size() <= i2)
              continue;
            msg(new StringBuilder().append("§c").append((String)((List)localObject1).get(i2)).toString());
          }
      }
      else
      {
        Object localObject6;
        if (arrayOfString1[0].equalsIgnoreCase("/reload"))
        {
          etc.getInstance().load();
          etc.getInstance().loadData();
          localObject1 = etc.getServer().getPlayerList().iterator();
          while (((Iterator)localObject1).hasNext())
          {
            localObject6 = (Player)((Iterator)localObject1).next();
            ((Player)localObject6).getUser().reloadPlayer();
          }
          a.info("Reloaded config");
          msg("Successfuly reloaded config");
        }
        else if ((arrayOfString1[0].equalsIgnoreCase("/modify")) || (arrayOfString1[0].equalsIgnoreCase("/mp")))
        {
          if (arrayOfString1.length < 4)
          {
            msg("§cUsage is: /modify [player] [key] [value]");
            msg("§cKeys:");
            msg("§cprefix: only the letter the color represents");
            msg("§ccommands: list seperated by comma");
            msg("§cgroups: list seperated by comma");
            msg("§cignoresrestrictions: true or false");
            msg("§cadmin: true or false");
            msg("§cmodworld: true or false");
            return;
          }
          localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
          if (localObject1 == null)
          {
            msg("§cPlayer does not exist.");
            return;
          }
          localObject6 = arrayOfString1[2];
          localObject8 = arrayOfString1[3];
          int i8 = 0;
          if (!etc.getDataSource().doesPlayerExist(((Player)localObject1).getName()))
          {
            if ((!((String)localObject6).equalsIgnoreCase("groups")) && (!((String)localObject6).equalsIgnoreCase("g")))
            {
              msg("§cWhen adding a new user, set their group(s) first.");
              return;
            }
            msg("§cAdding new user.");
            i8 = 1;
          }
          if ((((String)localObject6).equalsIgnoreCase("prefix")) || (((String)localObject6).equalsIgnoreCase("p")))
            ((Player)localObject1).setPrefix((String)localObject8);
          else if ((((String)localObject6).equalsIgnoreCase("commands")) || (((String)localObject6).equalsIgnoreCase("c")))
            ((Player)localObject1).setCommands(((String)localObject8).split(","));
          else if ((((String)localObject6).equalsIgnoreCase("groups")) || (((String)localObject6).equalsIgnoreCase("g")))
            ((Player)localObject1).setGroups(((String)localObject8).split(","));
          else if ((((String)localObject6).equalsIgnoreCase("ignoresrestrictions")) || (((String)localObject6).equalsIgnoreCase("ir")))
            ((Player)localObject1).setIgnoreRestrictions((((String)localObject8).equalsIgnoreCase("true")) || (((String)localObject8).equals("1")));
          else if ((((String)localObject6).equalsIgnoreCase("admin")) || (((String)localObject6).equalsIgnoreCase("a")))
            ((Player)localObject1).setAdmin((((String)localObject8).equalsIgnoreCase("true")) || (((String)localObject8).equals("1")));
          else if ((((String)localObject6).equalsIgnoreCase("modworld")) || (((String)localObject6).equalsIgnoreCase("mw")))
            ((Player)localObject1).setCanModifyWorld((((String)localObject8).equalsIgnoreCase("true")) || (((String)localObject8).equals("1")));
          if (i8 != 0)
            etc.getDataSource().addPlayer((Player)localObject1);
          else
            etc.getDataSource().modifyPlayer((Player)localObject1);
          msg("§cModified user.");
          a.info(new StringBuilder().append("Modifed user ").append(arrayOfString1[1]).append(". ").append((String)localObject6).append(" => ").append((String)localObject8).append(" by ").append(getPlayer().getName()).toString());
        }
        else if (arrayOfString1[0].equalsIgnoreCase("/whitelist"))
        {
          if (arrayOfString1.length < 2)
          {
            msg("§cwhitelist [operation (toggle, add or remove)] <player>");
            return;
          }
          if (arrayOfString1[1].equalsIgnoreCase("toggle"))
            msg(new StringBuilder().append("§c").append(etc.getInstance().toggleWhitelist() ? "Whitelist enabled" : "Whitelist disabled").toString());
          else if (arrayOfString1.length == 3)
          {
            if (arrayOfString1[1].equalsIgnoreCase("add"))
            {
              etc.getDataSource().addToWhitelist(arrayOfString1[2]);
              msg(new StringBuilder().append("§c").append(arrayOfString1[2]).append(" added to whitelist").toString());
            }
            else if (arrayOfString1[1].equalsIgnoreCase("remove"))
            {
              etc.getDataSource().removeFromWhitelist(arrayOfString1[2]);
              msg(new StringBuilder().append("§c").append(arrayOfString1[2]).append(" removed from whitelist").toString());
            }
            else
            {
              msg("§cInvalid operation.");
            }
          }
          else
            msg("§cInvalid operation.");
        }
        else if (arrayOfString1[0].equalsIgnoreCase("/reservelist"))
        {
          if (arrayOfString1.length != 3)
          {
            msg("§creservelist [operation (add or remove)] [player]");
            return;
          }
          if (arrayOfString1[1].equalsIgnoreCase("add"))
          {
            etc.getDataSource().addToReserveList(arrayOfString1[2]);
            msg(new StringBuilder().append("§c").append(arrayOfString1[2]).append(" added to reservelist").toString());
          }
          else if (arrayOfString1[1].equalsIgnoreCase("remove"))
          {
            etc.getDataSource().removeFromReserveList(arrayOfString1[2]);
            msg(new StringBuilder().append("§c").append(arrayOfString1[2]).append(" removed from reservelist").toString());
          }
          else
          {
            msg("§cInvalid operation.");
          }
        }
        else if (arrayOfString1[0].equalsIgnoreCase("/mute"))
        {
          if (arrayOfString1.length != 2)
          {
            msg("§cCorrect usage is: /mute [player]");
            return;
          }
          localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
          if (localObject1 != null)
          {
            if (((Player)localObject1).toggleMute())
              msg("§cplayer was muted");
            else
              msg("§cplayer was unmuted");
          }
          else
            msg(new StringBuilder().append("§cCan't find player ").append(arrayOfString1[1]).toString());
        }
        else if ((arrayOfString1[0].equalsIgnoreCase("/msg")) || (arrayOfString1[0].equalsIgnoreCase("/tell")) || (arrayOfString1[0].equalsIgnoreCase("/m")))
        {
          if (arrayOfString1.length < 3)
          {
            msg("§cCorrect usage is: /msg [player] [message]");
            return;
          }
          if (getPlayer().isMuted())
          {
            msg("§cYou are currently muted.");
            return;
          }
          localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
          if (localObject1 != null)
          {
            if (((Player)localObject1).getName().equals(getPlayer().getName()))
            {
              msg("§cYou can't message yourself!");
              return;
            }
            localObject6 = getPlayer().getColor();
            ((Player)localObject1).sendMessage(new StringBuilder().append("(MSG) ").append((String)localObject6).append("<").append(getPlayer().getName()).append("> ").append("§f").append(etc.combineSplit(2, arrayOfString1, " ")).toString());
            msg(new StringBuilder().append("(MSG) ").append((String)localObject6).append("<").append(getPlayer().getName()).append("> ").append("§f").append(etc.combineSplit(2, arrayOfString1, " ")).toString());
          }
          else
          {
            msg(new StringBuilder().append("§cCouldn't find player ").append(arrayOfString1[1]).toString());
          }
        }
        else
        {
          Object localObject9;
          if ((arrayOfString1[0].equalsIgnoreCase("/kit")) && (etc.getDataSource().hasKits()))
          {
            if ((arrayOfString1.length != 2) && (arrayOfString1.length != 3))
            {
              msg(new StringBuilder().append("§cAvailable kits§f: ").append(etc.getDataSource().getKitNames(getPlayer())).toString());
              return;
            }
            localObject1 = getPlayer();
            if ((arrayOfString1.length > 2) && (getPlayer().canIgnoreRestrictions()))
              localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
            localObject6 = etc.getDataSource().getKit(arrayOfString1[1]);
            if (localObject1 != null)
            {
              if (localObject6 != null)
              {
                if ((!getPlayer().isInGroup(((Kit)localObject6).Group)) && (!((Kit)localObject6).Group.equals("")))
                {
                  msg("§cThat kit does not exist.");
                }
                else if (this.onlyOneUseKits.contains(((Kit)localObject6).Name))
                {
                  msg("§cYou can only get this kit once per login.");
                }
                else if (MinecraftServer.b.containsKey(new StringBuilder().append(getPlayer().getName()).append(" ").append(((Kit)localObject6).Name).toString()))
                {
                  msg("§cYou can't get this kit again for a while.");
                }
                else
                {
                  if (!getPlayer().canIgnoreRestrictions())
                    if (((Kit)localObject6).Delay >= 0)
                      MinecraftServer.b.put(new StringBuilder().append(getPlayer().getName()).append(" ").append(((Kit)localObject6).Name).toString(), Integer.valueOf(((Kit)localObject6).Delay));
                    else
                      this.onlyOneUseKits.add(((Kit)localObject6).Name);
                  a.info(new StringBuilder().append(getPlayer().getName()).append(" got a kit!").toString());
                  ((Player)localObject1).sendMessage("§cEnjoy this kit!");
                  localObject8 = ((Kit)localObject6).IDs.entrySet().iterator();
                  while (((Iterator)localObject8).hasNext())
                  {
                    localObject9 = (Map.Entry)((Iterator)localObject8).next();
                    try
                    {
                      int i9 = 0;
                      try
                      {
                        i9 = Integer.parseInt((String)((Map.Entry)localObject9).getKey());
                      }
                      catch (NumberFormatException localNumberFormatException5)
                      {
                        i9 = etc.getDataSource().getItem((String)((Map.Entry)localObject9).getKey());
                      }
                      ((Player)localObject1).giveItem(i9, ((Integer)((Kit)localObject6).IDs.get(((Map.Entry)localObject9).getKey())).intValue());
                    }
                    catch (Exception localException)
                    {
                      a.info(new StringBuilder().append("Got an exception while giving out a kit (Kit name \"").append(((Kit)localObject6).Name).append("\"). Are you sure all the Ids are numbers?").toString());
                      msg("§cThe server encountered a problem while giving the kit :(");
                    }
                  }
                }
              }
              else
                msg("§cThat kit does not exist.");
            }
            else
              msg("§cThat user does not exist.");
          }
          else if (arrayOfString1[0].equalsIgnoreCase("/tp"))
          {
            if (arrayOfString1.length < 2)
            {
              msg("§cCorrect usage is: /tp [player]");
              return;
            }
            localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
            if (localObject1 != null)
            {
              if (getPlayer().getName().equalsIgnoreCase(((Player)localObject1).getName()))
              {
                msg("§cYou're already here!");
                return;
              }
              a.info(new StringBuilder().append(getPlayer().getName()).append(" teleported to ").append(((Player)localObject1).getName()).toString());
              getPlayer().teleportTo((BaseEntity)localObject1);
            }
            else
            {
              msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[1]).append(".").toString());
            }
          }
          else if ((arrayOfString1[0].equalsIgnoreCase("/tphere")) || (arrayOfString1[0].equalsIgnoreCase("/s")))
          {
            if (arrayOfString1.length < 2)
            {
              msg("§cCorrect usage is: /tphere [player]");
              return;
            }
            localObject1 = etc.getServer().matchPlayer(arrayOfString1[1]);
            if (localObject1 != null)
            {
              if (getPlayer().getName().equalsIgnoreCase(((Player)localObject1).getName()))
              {
                msg("§cWow look at that! You teleported yourself to yourself!");
                return;
              }
              a.info(new StringBuilder().append(getPlayer().getName()).append(" teleported ").append(((Player)localObject1).getName()).append(" to their self.").toString());
              ((Player)localObject1).teleportTo(getPlayer());
            }
            else
            {
              msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[1]).append(".").toString());
            }
          }
          else if ((arrayOfString1[0].equalsIgnoreCase("/playerlist")) || (arrayOfString1[0].equalsIgnoreCase("/who")))
          {
            msg(new StringBuilder().append("§cPlayer list (").append(this.d.f.b.size()).append("/").append(etc.getInstance().getPlayerLimit()).append("): ").append("§f").append(this.d.f.c()).toString());
          }
          else
          {
            int i7;
            if ((arrayOfString1[0].equalsIgnoreCase("/item")) || (arrayOfString1[0].equalsIgnoreCase("/i")) || (arrayOfString1[0].equalsIgnoreCase("/give")))
            {
              if (arrayOfString1.length < 2)
              {
                if (getPlayer().canIgnoreRestrictions())
                  msg("§cCorrect usage is: /item [itemid] <amount> <player> (optional)");
                else
                  msg("§cCorrect usage is: /item [itemid] <amount>");
                return;
              }
              localObject1 = getPlayer();
              if ((arrayOfString1.length == 4) && (getPlayer().canIgnoreRestrictions()))
                localObject1 = etc.getServer().matchPlayer(arrayOfString1[3]);
              if (localObject1 != null)
                try
                {
                  int i3 = 0;
                  try
                  {
                    i3 = Integer.parseInt(arrayOfString1[1]);
                  }
                  catch (NumberFormatException localNumberFormatException4)
                  {
                    i3 = etc.getDataSource().getItem(arrayOfString1[1]);
                  }
                  i7 = 1;
                  if (arrayOfString1.length > 2)
                    i7 = Integer.parseInt(arrayOfString1[2]);
                  localObject9 = Integer.toString(i3);
                  if ((i7 <= 0) && (!getPlayer().isAdmin()))
                    i7 = 1;
                  if ((i7 > 64) && (!getPlayer().canIgnoreRestrictions()))
                    i7 = 64;
                  if (i7 > 1024)
                    i7 = 1024;
                  int i10 = 0;
                  String str2;
                  if ((!etc.getInstance().getAllowedItems()[0].equals("")) && (!getPlayer().canIgnoreRestrictions()))
                    for (str2 : etc.getInstance().getAllowedItems())
                    {
                      if (!((String)localObject9).equals(str2))
                        continue;
                      i10 = 1;
                    }
                  else
                    i10 = 1;
                  if ((!etc.getInstance().getDisallowedItems()[0].equals("")) && (!getPlayer().canIgnoreRestrictions()))
                    for (str2 : etc.getInstance().getDisallowedItems())
                    {
                      if (!((String)localObject9).equals(str2))
                        continue;
                      i10 = 0;
                    }
                  if (Item.isValidItem(i3))
                  {
                    if ((i10 != 0) || (getPlayer().canIgnoreRestrictions()))
                    {
                      a.log(Level.INFO, new StringBuilder().append("Giving ").append(((Player)localObject1).getName()).append(" some ").append(i3).toString());
                      ((Player)localObject1).giveItem(i3, i7);
                      if (((Player)localObject1).getName().equalsIgnoreCase(getPlayer().getName()))
                      {
                        msg("§cThere you go c:");
                      }
                      else
                      {
                        msg("§cGift given! :D");
                        ((Player)localObject1).sendMessage("§cEnjoy your gift! :D");
                      }
                    }
                    else if ((i10 == 0) && (!getPlayer().canIgnoreRestrictions()))
                    {
                      msg("§cYou are not allowed to spawn that item.");
                    }
                  }
                  else
                    msg(new StringBuilder().append("§cNo item with ID ").append(arrayOfString1[1]).toString());
                }
                catch (NumberFormatException localNumberFormatException3)
                {
                  msg("§cImproper ID and/or amount.");
                }
              else
                msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[3]).toString());
            }
            else
            {
              int m;
              if (arrayOfString1[0].equalsIgnoreCase("/tempban"))
              {
                if (arrayOfString1.length == 1)
                  return;
                m = 0;
                int i4 = 0;
                i7 = 0;
                if (arrayOfString1.length >= 2)
                  m = Integer.parseInt(arrayOfString1[1]);
                if (arrayOfString1.length >= 3)
                  i4 = Integer.parseInt(arrayOfString1[2]);
                if (arrayOfString1.length >= 4)
                  i7 = Integer.parseInt(arrayOfString1[3]);
                localObject9 = new Date();
              }
              else if (arrayOfString1[0].equalsIgnoreCase("/banlist"))
              {
                m = 0;
                if ((arrayOfString1.length == 2) && (arrayOfString1[1].equalsIgnoreCase("ips")))
                  m = 1;
                if (m == 0)
                  msg(new StringBuilder().append("§3Ban list:§f ").append(this.d.f.getBans()).toString());
                else
                  msg(new StringBuilder().append("§3IP Ban list:§f ").append(this.d.f.getBans()).toString());
              }
              else
              {
                Object localObject2;
                if (arrayOfString1[0].equalsIgnoreCase("/banip"))
                {
                  if (arrayOfString1.length < 2)
                  {
                    msg("§cCorrect usage is: /banip [player] <reason> (optional) NOTE: this permabans IPs.");
                    return;
                  }
                  localObject2 = etc.getServer().matchPlayer(arrayOfString1[1]);
                  if (localObject2 != null)
                  {
                    if (!getPlayer().hasControlOver((Player)localObject2))
                    {
                      msg("§cYou can't ban that user.");
                      return;
                    }
                    this.d.f.c(((Player)localObject2).getIP());
                    etc.getLoader().callHook(PluginLoader.Hook.IPBAN, new Object[] { getPlayer().getUser(), ((Player)localObject2).getUser(), arrayOfString1.length >= 3 ? etc.combineSplit(2, arrayOfString1, " ") : "" });
                    a.log(Level.INFO, new StringBuilder().append("IP Banning ").append(((Player)localObject2).getName()).append(" (IP: ").append(((Player)localObject2).getIP()).append(")").toString());
                    msg(new StringBuilder().append("§cIP Banning ").append(((Player)localObject2).getName()).append(" (IP: ").append(((Player)localObject2).getIP()).append(")").toString());
                    if (arrayOfString1.length > 2)
                      ((Player)localObject2).kick(new StringBuilder().append("IP Banned by ").append(getPlayer().getName()).append(": ").append(etc.combineSplit(2, arrayOfString1, " ")).toString());
                    else
                      ((Player)localObject2).kick(new StringBuilder().append("IP Banned by ").append(getPlayer().getName()).append(".").toString());
                  }
                  else
                  {
                    msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[1]).append(".").toString());
                  }
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/ban"))
                {
                  if (arrayOfString1.length < 2)
                  {
                    msg("§cCorrect usage is: /ban [player] <reason> (optional)");
                    return;
                  }
                  localObject2 = etc.getServer().matchPlayer(arrayOfString1[1]);
                  if (localObject2 != null)
                  {
                    if (!getPlayer().hasControlOver((Player)localObject2))
                    {
                      msg("§cYou can't ban that user.");
                      return;
                    }
                    this.d.f.a(((Player)localObject2).getName());
                    etc.getLoader().callHook(PluginLoader.Hook.BAN, new Object[] { getPlayer().getUser(), ((Player)localObject2).getUser(), arrayOfString1.length >= 3 ? etc.combineSplit(2, arrayOfString1, " ") : "" });
                    if (arrayOfString1.length > 2)
                      ((Player)localObject2).kick(new StringBuilder().append("Banned by ").append(getPlayer().getName()).append(": ").append(etc.combineSplit(2, arrayOfString1, " ")).toString());
                    else
                      ((Player)localObject2).kick(new StringBuilder().append("Banned by ").append(getPlayer().getName()).append(".").toString());
                    a.log(Level.INFO, new StringBuilder().append("Banning ").append(((Player)localObject2).getName()).toString());
                    msg(new StringBuilder().append("§cBanning ").append(((Player)localObject2).getName()).toString());
                  }
                  else
                  {
                    msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[1]).append(".").toString());
                  }
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/unban"))
                {
                  if (arrayOfString1.length != 2)
                  {
                    msg("§cCorrect usage is: /unban [player]");
                    return;
                  }
                  this.d.f.b(arrayOfString1[1]);
                  msg(new StringBuilder().append("§cUnbanned ").append(arrayOfString1[1]).toString());
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/unbanip"))
                {
                  if (arrayOfString1.length != 2)
                  {
                    msg("§cCorrect usage is: /unbanip [ip]");
                    return;
                  }
                  this.d.f.d(arrayOfString1[1]);
                  msg(new StringBuilder().append("§cUnbanned ").append(arrayOfString1[1]).toString());
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/kick"))
                {
                  if (arrayOfString1.length < 2)
                  {
                    msg("§cCorrect usage is: /kick [player] <reason> (optional)");
                    return;
                  }
                  localObject2 = etc.getServer().matchPlayer(arrayOfString1[1]);
                  if (localObject2 != null)
                  {
                    if (!getPlayer().hasControlOver((Player)localObject2))
                    {
                      msg("§cYou can't kick that user.");
                      return;
                    }
                    etc.getLoader().callHook(PluginLoader.Hook.KICK, new Object[] { getPlayer().getUser(), ((Player)localObject2).getUser(), arrayOfString1.length >= 3 ? etc.combineSplit(2, arrayOfString1, " ") : "" });
                    if (arrayOfString1.length > 2)
                      ((Player)localObject2).kick(new StringBuilder().append("Kicked by ").append(getPlayer().getName()).append(": ").append(etc.combineSplit(2, arrayOfString1, " ")).toString());
                    else
                      ((Player)localObject2).kick(new StringBuilder().append("Kicked by ").append(getPlayer().getName()).append(".").toString());
                    a.log(Level.INFO, new StringBuilder().append("Kicking ").append(((Player)localObject2).getName()).toString());
                    msg(new StringBuilder().append("§cKicking ").append(((Player)localObject2).getName()).toString());
                  }
                  else
                  {
                    msg(new StringBuilder().append("§cCan't find user ").append(arrayOfString1[1]).append(".").toString());
                  }
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/me"))
                {
                  if (getPlayer().isMuted())
                  {
                    msg("§cYou are currently muted.");
                    return;
                  }
                  if (arrayOfString1.length == 1)
                    return;
                  localObject2 = getPlayer().getColor();
                  String str1 = new StringBuilder().append("* ").append((String)localObject2).append(getPlayer().getName()).append("§f").append(" ").append(paramString.substring(paramString.indexOf(" ")).trim()).toString();
                  a.info(new StringBuilder().append("* ").append(getPlayer().getName()).append(" ").append(paramString.substring(paramString.indexOf(" ")).trim()).toString());
                  this.d.f.a(new ba(str1));
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/sethome"))
                {
                  localObject2 = new Warp();
                  ((Warp)localObject2).Location = getPlayer().getLocation();
                  ((Warp)localObject2).Group = "";
                  ((Warp)localObject2).Name = getPlayer().getName();
                  etc.getInstance().changeHome((Warp)localObject2);
                  msg("§cYour home has been set.");
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/spawn"))
                {
                  int n = this.d.e.d(this.d.e.n, this.d.e.p);
                  a(this.d.e.n + 0.5D, n + 1.5D, this.d.e.p + 0.5D, 0.0F, 0.0F);
                }
                else if (arrayOfString1[0].equalsIgnoreCase("/setspawn"))
                {
                  this.d.e.n = (int)Math.ceil(getPlayer().getX());
                  this.d.e.p = (int)Math.ceil(getPlayer().getZ());
                  a.info("Spawn position changed.");
                  msg("§cYou have set the spawn to your current position.");
                }
                else
                {
                  Object localObject3;
                  if (arrayOfString1[0].equalsIgnoreCase("/home"))
                  {
                    localObject3 = null;
                    if ((arrayOfString1.length > 1) && (getPlayer().isAdmin()))
                      localObject3 = etc.getDataSource().getHome(arrayOfString1[1]);
                    else
                      localObject3 = etc.getDataSource().getHome(getPlayer().getName());
                    if (localObject3 != null)
                    {
                      getPlayer().teleportTo(((Warp)localObject3).Location);
                    }
                    else if ((arrayOfString1.length > 1) && (getPlayer().isAdmin()))
                    {
                      msg("§cThat player home does not exist");
                    }
                    else
                    {
                      int i5 = this.d.e.d(this.d.e.n, this.d.e.p);
                      a(this.d.e.n + 0.5D, i5 + 1.5D, this.d.e.p + 0.5D, 0.0F, 0.0F);
                    }
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/warp"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      msg("§cCorrect usage is: /warp [warpname]");
                      return;
                    }
                    localObject3 = getPlayer();
                    Warp localWarp = null;
                    if ((arrayOfString1.length == 3) && (getPlayer().canIgnoreRestrictions()))
                    {
                      localWarp = etc.getDataSource().getWarp(arrayOfString1[1]);
                      localObject3 = etc.getServer().matchPlayer(arrayOfString1[2]);
                    }
                    else
                    {
                      localWarp = etc.getDataSource().getWarp(arrayOfString1[1]);
                    }
                    if (localObject3 != null)
                    {
                      if (localWarp != null)
                      {
                        if ((!getPlayer().isInGroup(localWarp.Group)) && (!localWarp.Group.equals("")))
                        {
                          msg("§cWarp not found.");
                        }
                        else
                        {
                          ((Player)localObject3).teleportTo(localWarp.Location);
                          ((Player)localObject3).sendMessage("§cWoosh!");
                        }
                      }
                      else
                        msg("§cWarp not found");
                    }
                    else
                      msg("§cPlayer not found.");
                  }
                  else if ((arrayOfString1[0].equalsIgnoreCase("/listwarps")) && (etc.getDataSource().hasWarps()))
                  {
                    if ((arrayOfString1.length != 2) && (arrayOfString1.length != 3))
                    {
                      msg(new StringBuilder().append("§cAvailable warps: §f").append(etc.getDataSource().getWarpNames(getPlayer())).toString());
                      return;
                    }
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/setwarp"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      if (getPlayer().canIgnoreRestrictions())
                        msg("§cCorrect usage is: /setwarp [warpname] [group]");
                      else
                        msg("§cCorrect usage is: /setwarp [warpname]");
                      return;
                    }
                    if (arrayOfString1[1].contains(":"))
                    {
                      msg("You can't set a warp with \":\" in its name");
                      return;
                    }
                    localObject3 = new Warp();
                    ((Warp)localObject3).Name = arrayOfString1[1];
                    ((Warp)localObject3).Location = getPlayer().getLocation();
                    if (arrayOfString1.length == 3)
                      ((Warp)localObject3).Group = arrayOfString1[2];
                    else
                      ((Warp)localObject3).Group = "";
                    etc.getInstance().setWarp((Warp)localObject3);
                    msg(new StringBuilder().append("§cCreated warp point ").append(arrayOfString1[1]).append(".").toString());
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/removewarp"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      msg("§cCorrect usage is: /removewarp [warpname]");
                      return;
                    }
                    localObject3 = etc.getDataSource().getWarp(arrayOfString1[1]);
                    if (localObject3 != null)
                    {
                      etc.getDataSource().removeWarp((Warp)localObject3);
                      msg("§3Warp removed.");
                    }
                    else
                    {
                      msg("§cThat warp does not exist");
                    }
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/lighter"))
                  {
                    if (MinecraftServer.b.containsKey(new StringBuilder().append(getPlayer().getName()).append(" lighter").toString()))
                    {
                      a.info(new StringBuilder().append(getPlayer().getName()).append(" failed to iron!").toString());
                      msg("§cYou can't create another lighter again so soon");
                    }
                    else
                    {
                      if (!getPlayer().canIgnoreRestrictions())
                        MinecraftServer.b.put(new StringBuilder().append(getPlayer().getName()).append(" lighter").toString(), Integer.valueOf(6000));
                      a.info(new StringBuilder().append(getPlayer().getName()).append(" created a lighter!").toString());
                      getPlayer().giveItem(259, 1);
                    }
                  }
                  else if ((paramString.startsWith("/#")) && (this.d.f.g(getPlayer().getName())))
                  {
                    localObject3 = paramString.substring(2);
                    a.info(new StringBuilder().append(getPlayer().getName()).append(" issued server command: ").append((String)localObject3).toString());
                    this.d.a((String)localObject3, this);
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/time"))
                  {
                    if (arrayOfString1.length != 2)
                    {
                      msg("§cCorrect usage is: /time [time|day|night]");
                      return;
                    }
                    if (arrayOfString1[1].equalsIgnoreCase("day"))
                      this.d.e.c = 0L;
                    else if (arrayOfString1[1].equalsIgnoreCase("night"))
                      this.d.e.c = 13000L;
                    else
                      try
                      {
                        this.d.e.c = Long.parseLong(arrayOfString1[1]);
                      }
                      catch (NumberFormatException localNumberFormatException1)
                      {
                        msg("§cPlease enter numbers, not letters.");
                      }
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/getpos"))
                  {
                    Player localPlayer1 = getPlayer();
                    msg(new StringBuilder().append("Pos X: ").append(localPlayer1.getX()).append(" Y: ").append(localPlayer1.getY()).append(" Z: ").append(localPlayer1.getZ()).toString());
                    msg(new StringBuilder().append("Rotation: ").append(localPlayer1.getRotation()).append(" Pitch: ").append(localPlayer1.getPitch()).toString());
                    double d2 = (localPlayer1.getRotation() - 90.0F) % 360.0F;
                    if (d2 < 0.0D)
                      d2 += 360.0D;
                    msg(new StringBuilder().append("Compass: ").append(etc.getCompassPointForDirection(d2)).append(" (").append(Math.round(d2 * 10.0D) / 10.0D).append(")").toString());
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/listplugins"))
                  {
                    msg(new StringBuilder().append("§cPlugins§f: ").append(etc.getLoader().getPluginList()).toString());
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/reloadplugin"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      msg("§cCorrect usage is: /reloadplugin [plugin]");
                      return;
                    }
                    etc.getLoader().reloadPlugin(arrayOfString1[1]);
                    msg("§cPlugin reloaded.");
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/enableplugin"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      msg("§cCorrect usage is: /enableplugin [plugin]");
                      return;
                    }
                    etc.getLoader().enablePlugin(arrayOfString1[1]);
                    msg("§cPlugin enabled.");
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/disableplugin"))
                  {
                    if (arrayOfString1.length < 2)
                    {
                      msg("§cCorrect usage is: /enableplugin [plugin]");
                      return;
                    }
                    etc.getLoader().disablePlugin(arrayOfString1[1]);
                    msg("§cPlugin disabled.");
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/compass"))
                  {
                    double d1 = (getPlayer().getRotation() - 90.0F) % 360.0F;
                    if (d1 < 0.0D)
                      d1 += 360.0D;
                    msg(new StringBuilder().append("§cCompass: ").append(etc.getCompassPointForDirection(d1)).toString());
                  }
                  else if (arrayOfString1[0].equalsIgnoreCase("/motd"))
                  {
                    for (localObject9 : etc.getInstance().getMotd())
                      msg((String)localObject9);
                  }
                  else
                  {
                    Object localObject7;
                    if (arrayOfString1[0].equalsIgnoreCase("/spawnmob"))
                    {
                      if (arrayOfString1.length == 1)
                      {
                        msg("§cCorrect usage is: /spawnmob [name] <amount>");
                        return;
                      }
                      if (!Mob.isValid(arrayOfString1[1]))
                      {
                        msg("§cInvalid mob. Name has to start with a capital like so: Pig");
                        return;
                      }
                      if (arrayOfString1.length == 2)
                      {
                        ??? = new Mob(arrayOfString1[1], getPlayer().getLocation());
                        ((Mob)???).spawn();
                      }
                      else if (arrayOfString1.length == 3)
                      {
                        for (int i1 = 0; i1 < Integer.parseInt(arrayOfString1[2]); i1++)
                        {
                          localObject7 = new Mob(arrayOfString1[1], getPlayer().getLocation());
                          ((Mob)localObject7).spawn();
                        }
                      }
                    }
                    else if (arrayOfString1[0].equalsIgnoreCase("/clearinventory"))
                    {
                      Player localPlayer2 = getPlayer();
                      if ((arrayOfString1.length >= 2) && (getPlayer().isAdmin()))
                        localPlayer2 = etc.getServer().matchPlayer(arrayOfString1[1]);
                      if (localPlayer2 != null)
                      {
                        localObject7 = localPlayer2.getInventory();
                        ((Inventory)localObject7).clearContents();
                        localObject7 = localPlayer2.getCraftingTable();
                        ((Inventory)localObject7).clearContents();
                        localObject7 = localPlayer2.getEquipment();
                        ((Inventory)localObject7).clearContents();
                        ((Inventory)localObject7).updateInventory();
                        if (!localPlayer2.getName().equals(getPlayer().getName()))
                          msg(new StringBuilder().append("§cCleared ").append(localPlayer2.getName()).append("'s inventory.").toString());
                      }
                      else
                      {
                        msg("§cTarget not found");
                      }
                    }
                    else if (arrayOfString1[0].equalsIgnoreCase("/version"))
                    {
                      msg(new StringBuilder().append("§6Hey0 Server Mod Build ").append(etc.getInstance().getVersion()).toString());
                    }
                    else
                    {
                      a.info(new StringBuilder().append(getPlayer().getName()).append(" tried command ").append(paramString).toString());
                      if (etc.getInstance().showUnknownCommand())
                        msg("§cUnknown command");
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    catch (Throwable localThrowable)
    {
      a.log(Level.SEVERE, "Exception in command handler (Report this to hey0 unless you did something dumb like enter letters as numbers):", localThrowable);
      if (getPlayer().isAdmin())
        msg("§cException occured. Check the server for more info.");
    }
  }

  public void a(o paramo)
  {
    if (paramo.b == 1)
    {
      etc.getLoader().callHook(PluginLoader.Hook.ARM_SWING, new Object[] { this.e });
      this.e.z();
    }
  }

  public void a(io paramio)
  {
    this.b.a("Quitting");
  }

  public int b()
  {
    return this.b.d();
  }

  public void b(String paramString)
  {
    b(new ba(new StringBuilder().append("§7").append(paramString).toString()));
  }

  public String c()
  {
    return getPlayer().getName();
  }

  public void a(r paramr)
  {
    if (!getPlayer().canBuild())
      return;
    if (paramr.a == -1)
    {
      gp[] arrayOfgp = this.e.aj.a;
      this.e.aj.a = paramr.b;
      if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.INVENTORY_CHANGE, new Object[] { this.e })).booleanValue())
      {
        this.e.aj.a = arrayOfgp;
        getPlayer().getInventory().updateInventory();
      }
    }
    if (paramr.a == -2)
      this.e.aj.c = paramr.b;
    if (paramr.a == -3)
      this.e.aj.b = paramr.b;
  }

  public void d()
  {
    this.b.a(new r(-1, this.e.aj.a));
    this.b.a(new r(-2, this.e.aj.c));
    this.b.a(new r(-3, this.e.aj.b));
  }

  public void a(ib paramib)
  {
    if (!getPlayer().canBuild())
      return;
    as localas = this.d.e.k(paramib.a, paramib.b, paramib.c);
    if (localas != null)
    {
      Object localObject1;
      Object localObject2;
      if ((localas instanceof hb))
      {
        localObject1 = (hb)localas;
        localObject2 = ((hb)localObject1).getContents();
        localas.a(paramib.e);
        if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.COMPLEX_BLOCK_CHANGE, new Object[] { this.e, new Chest((hb)localObject1) })).booleanValue())
          ((hb)localObject1).setContents(localObject2);
      }
      else if ((localas instanceof df))
      {
        localObject1 = (df)localas;
        localObject2 = ((df)localObject1).getContents();
        localas.a(paramib.e);
        if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.COMPLEX_BLOCK_CHANGE, new Object[] { this.e, new Furnace((df)localObject1) })).booleanValue())
          ((df)localObject1).setContents(localObject2);
      }
      else if ((localas instanceof ig))
      {
        localObject1 = (ig)localas;
        localObject2 = ((ig)localObject1).e;
        localas.a(paramib.e);
        if (((Boolean)etc.getLoader().callHook(PluginLoader.Hook.COMPLEX_BLOCK_CHANGE, new Object[] { this.e, new Sign((ig)localObject1) })).booleanValue())
          ((ig)localObject1).e = ((String)localObject2);
      }
      localas.c();
    }
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     id
 * JD-Core Version:    0.6.0
 */