import java.util.Map;

public class Kit
{
  public int ID;
  public String Name;
  public Map<String, Integer> IDs;
  public int Delay;
  public String Group;
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Kit
 * JD-Core Version:    0.6.0
 */