public abstract class Plugin
{
  private String name = "";
  private boolean enabled = true;
  private boolean usesListeners;

  public abstract void enable();

  public abstract void disable();

  public boolean isEnabled()
  {
    return this.enabled;
  }

  public boolean toggleEnabled()
  {
    this.enabled = (!this.enabled);
    return this.enabled;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void initialize()
  {
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     Plugin
 * JD-Core Version:    0.6.0
 */