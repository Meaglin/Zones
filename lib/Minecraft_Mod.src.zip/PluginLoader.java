import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;

public class PluginLoader
{
  private static final Logger log = Logger.getLogger("Minecraft");
  private static final Object lock = new Object();
  private List<Plugin> plugins = new ArrayList();
  private List<List<PluginRegisteredListener>> listeners = new ArrayList();
  private Server server;
  private PropertiesFile properties = new PropertiesFile("server.properties");

  public PluginLoader(MinecraftServer paramMinecraftServer)
  {
    this.server = new Server(paramMinecraftServer);
    for (int i = 0; i < PluginLoader.Hook.NUM_HOOKS.ordinal(); i++)
      this.listeners.add(new ArrayList());
  }

  public void loadPlugins()
  {
    String[] arrayOfString1 = this.properties.getString("plugins", "").split(",");
    for (String str : arrayOfString1)
    {
      if (str.equals(""))
        continue;
      loadPlugin(str);
    }
  }

  public void loadPlugin(String paramString)
  {
    if (getPlugin(paramString) != null)
      return;
    load(paramString);
  }

  public void reloadPlugin(String paramString)
  {
    Plugin localPlugin = getPlugin(paramString);
    if ((localPlugin != null) && (localPlugin.isEnabled()))
      localPlugin.disable();
    synchronized (lock)
    {
      this.plugins.remove(localPlugin);
      Iterator localIterator1 = this.listeners.iterator();
      while (localIterator1.hasNext())
      {
        List localList = (List)localIterator1.next();
        Iterator localIterator2 = localList.iterator();
        while (localIterator2.hasNext())
        {
          if (((PluginRegisteredListener)localIterator2.next()).getPlugin() != localPlugin)
            continue;
          localIterator2.remove();
        }
      }
    }
    localPlugin = null;
    load(paramString);
  }

  private void load(String paramString)
  {
    try
    {
      File localFile = new File(new StringBuilder().append("plugins/").append(paramString).append(".jar").toString());
      MyClassLoader localMyClassLoader = null;
      try
      {
        localMyClassLoader = new MyClassLoader(new URL[] { localFile.toURI().toURL() }, Thread.currentThread().getContextClassLoader());
      }
      catch (MalformedURLException localMalformedURLException)
      {
        log.log(Level.SEVERE, "Exception while loading class", localMalformedURLException);
      }
      Class localClass = Class.forName(paramString, true, localMyClassLoader);
      Plugin localPlugin = (Plugin)localClass.newInstance();
      localPlugin.setName(paramString);
      localPlugin.enable();
      synchronized (lock)
      {
        this.plugins.add(localPlugin);
        localPlugin.initialize();
      }
    }
    catch (Throwable localThrowable)
    {
      log.log(Level.SEVERE, "Exception while loading plugin", localThrowable);
    }
  }

  public Plugin getPlugin(String paramString)
  {
    synchronized (lock)
    {
      Iterator localIterator = this.plugins.iterator();
      while (localIterator.hasNext())
      {
        Plugin localPlugin = (Plugin)localIterator.next();
        if (localPlugin.getName().equalsIgnoreCase(paramString))
          return localPlugin;
      }
    }
    return null;
  }

  public String getPluginList()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    synchronized (lock)
    {
      Iterator localIterator = this.plugins.iterator();
      while (localIterator.hasNext())
      {
        Plugin localPlugin = (Plugin)localIterator.next();
        localStringBuilder.append(localPlugin.getName());
        localStringBuilder.append(" ");
        localStringBuilder.append(localPlugin.isEnabled() ? "(E)" : "(D)");
        localStringBuilder.append(",");
      }
    }
    ??? = localStringBuilder.toString();
    if (((String)???).length() > 1)
      return ((String)???).substring(0, ((String)???).length() - 1);
    return (String)"Empty";
  }

  public boolean enablePlugin(String paramString)
  {
    Plugin localPlugin = getPlugin(paramString);
    if (localPlugin != null)
    {
      if (!localPlugin.isEnabled())
      {
        localPlugin.toggleEnabled();
        localPlugin.enable();
      }
    }
    else
    {
      File localFile = new File(new StringBuilder().append("plugins/").append(paramString).append(".jar").toString());
      if (localFile.exists())
        loadPlugin(paramString);
      else
        return false;
    }
    return true;
  }

  public void disablePlugin(String paramString)
  {
    Plugin localPlugin = getPlugin(paramString);
    if ((localPlugin != null) && (localPlugin.isEnabled()))
    {
      localPlugin.toggleEnabled();
      localPlugin.disable();
    }
  }

  public Server getServer()
  {
    return this.server;
  }

  public Object callHook(PluginLoader.Hook paramHook, Object[] paramArrayOfObject)
  {
    Object localObject1 = Boolean.valueOf(false);
    synchronized (lock)
    {
      try
      {
        List localList = (List)this.listeners.get(paramHook.ordinal());
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          PluginRegisteredListener localPluginRegisteredListener = (PluginRegisteredListener)localIterator.next();
          if (!localPluginRegisteredListener.getPlugin().isEnabled())
            continue;
          PluginListener localPluginListener = localPluginRegisteredListener.getListener();
          try
          {
            switch (PluginLoader.1.$SwitchMap$PluginLoader$Hook[paramHook.ordinal()])
            {
            case 1:
              String str = localPluginListener.onLoginChecks((String)paramArrayOfObject[0]);
              if (str == null)
                break;
              localObject1 = str;
              break;
            case 2:
              localPluginListener.onLogin(((ea)paramArrayOfObject[0]).getPlayer());
              break;
            case 3:
              localPluginListener.onDisconnect(((ea)paramArrayOfObject[0]).getPlayer());
              break;
            case 4:
              if (!localPluginListener.onChat(((ea)paramArrayOfObject[0]).getPlayer(), (String)paramArrayOfObject[1]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 5:
              if (!localPluginListener.onCommand(((ea)paramArrayOfObject[0]).getPlayer(), (String[])(String[])paramArrayOfObject[1]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 6:
              if (!localPluginListener.onConsoleCommand((String[])(String[])paramArrayOfObject[0]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 7:
              localPluginListener.onBan(((ea)paramArrayOfObject[0]).getPlayer(), ((ea)paramArrayOfObject[1]).getPlayer(), (String)paramArrayOfObject[2]);
              break;
            case 8:
              localPluginListener.onIpBan(((ea)paramArrayOfObject[0]).getPlayer(), ((ea)paramArrayOfObject[1]).getPlayer(), (String)paramArrayOfObject[2]);
              break;
            case 9:
              localPluginListener.onKick(((ea)paramArrayOfObject[0]).getPlayer(), ((ea)paramArrayOfObject[1]).getPlayer(), (String)paramArrayOfObject[2]);
              break;
            case 10:
              if (!localPluginListener.onBlockCreate(((ea)paramArrayOfObject[0]).getPlayer(), (Block)paramArrayOfObject[1], (Block)paramArrayOfObject[2], ((Integer)paramArrayOfObject[3]).intValue()))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 11:
              if (!localPluginListener.onBlockDestroy(((ea)paramArrayOfObject[0]).getPlayer(), (Block)paramArrayOfObject[1]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 12:
              localPluginListener.onPlayerMove(((ea)paramArrayOfObject[0]).getPlayer(), (Location)paramArrayOfObject[1], (Location)paramArrayOfObject[2]);
              break;
            case 13:
              localPluginListener.onArmSwing(((ea)paramArrayOfObject[0]).getPlayer());
              break;
            case 14:
              if (!localPluginListener.onInventoryChange(((ea)paramArrayOfObject[0]).getPlayer()))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 15:
              if (!localPluginListener.onComplexBlockChange(((ea)paramArrayOfObject[0]).getPlayer(), (ComplexBlock)paramArrayOfObject[1]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 16:
              if (!localPluginListener.onSendComplexBlock(((ea)paramArrayOfObject[0]).getPlayer(), (ComplexBlock)paramArrayOfObject[1]))
                break;
              localObject1 = Boolean.valueOf(true);
              break;
            case 17:
              if (!localPluginListener.onTeleport(((ea)paramArrayOfObject[0]).getPlayer(), (Location)paramArrayOfObject[1], (Location)paramArrayOfObject[2]))
                break;
              localObject1 = Boolean.valueOf(true);
            }
          }
          catch (UnsupportedOperationException localUnsupportedOperationException)
          {
          }
        }
      }
      catch (Exception localException)
      {
        log.log(Level.SEVERE, "Exception while calling plugin function", localException);
      }
      catch (Throwable localThrowable)
      {
        log.log(Level.SEVERE, "Throwable while calling plugin (Outdated?)", localThrowable);
      }
    }
    return localObject1;
  }

  public PluginRegisteredListener addListener(PluginLoader.Hook paramHook, PluginListener paramPluginListener, Plugin paramPlugin, PluginListener.Priority paramPriority)
  {
    int i = paramPriority.ordinal();
    PluginRegisteredListener localPluginRegisteredListener1 = new PluginRegisteredListener(paramHook, paramPluginListener, paramPlugin, i);
    synchronized (lock)
    {
      List localList = (List)this.listeners.get(paramHook.ordinal());
      int j = 0;
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        PluginRegisteredListener localPluginRegisteredListener2 = (PluginRegisteredListener)localIterator.next();
        if (localPluginRegisteredListener2.getPriority() < i)
          break;
        j++;
      }
      localList.add(j, localPluginRegisteredListener1);
    }
    return localPluginRegisteredListener1;
  }

  public void removeListener(PluginRegisteredListener paramPluginRegisteredListener)
  {
    List localList = (List)this.listeners.get(paramPluginRegisteredListener.getHook().ordinal());
    synchronized (lock)
    {
      localList.remove(paramPluginRegisteredListener);
    }
  }

  public static enum Hook
  {
    LOGINCHECK, LOGIN, CHAT, COMMAND, SERVERCOMMAND, BAN, IPBAN, KICK, BLOCK_CREATED, BLOCK_DESTROYED, DISCONNECT, PLAYER_MOVE, ARM_SWING, COMPLEX_BLOCK_CHANGE, INVENTORY_CHANGE, COMPLEX_BLOCK_SEND, TELEPORT, NUM_HOOKS;
  }
}

/* Location:           C:\Users\Joseph Verburg\Desktop\s7\Minecraft_Mod.jar
 * Qualified Name:     PluginLoader
 * JD-Core Version:    0.6.0
 */